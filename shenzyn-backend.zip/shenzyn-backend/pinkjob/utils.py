#This file will use for writing global functions which can be used in many files
from django.core.mail import send_mail
import random
import json
import os.path
import re


# This is use to store all error and sucees message to message attribute from json file
with open(os.path.dirname(__file__) + "/message.json",encoding="utf-8") as fr:
    JsonMessage = json.load(fr)
    Message = JsonMessage


# This function will take email id and return true if it valid email id
# In this function we are validating email id by using django.core.validators
def is_email_valid(email_id):
    from django.core.validators import validate_email
    from django.core.exceptions import ValidationError
    try:
        # validate_email(email_id)
        return bool(re.match(r"(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.([a-zA-Z0-9-.])+$)", email_id))
    except ValidationError:
        return False


# This function will verify if the email entered is valid or not and if valid then follows length standards
def email_length_check(email_id):
    if email_id == '':
        return {"result": False, "message": "Kindly specify your Email Id!"}
    else:
        split = email_id.split("@")
        if len(split[0]) > 64:
            print(10)
            return {"result": False, "message": "Local Part exceeds 64 characters limit!"}
        elif len(split[1]) > 255:
            print(9)
            return {"result": False, "message": "Domain Part exceeds 255 characters limit!"}
        elif len(email_id) > 320:
            print(8)
            return {"result": False, "message": "Total Length exceeds 320 characters limit!"}
        elif is_email_valid(email_id):
            print(7)
            return {"result": True, "message": "Email seems valid!"}
        else:
            return {"result": False, "message": "Please enter a Valid Email!"}


# This function will check given password is valid or not
# As per FRD password validation should contain minimum 1 number and 1 alphabate
# and length between 8 to 20 characters
def is_password_valid(password):
    numbers_length = sum(c.isdigit() for c in password)
    words_length = sum(c.isalpha() for c in password)
    password_length = len(password)
    if numbers_length >= 1 and words_length >= 1 and password_length <= 20 and password_length >= 8:
        return True
    else:
        return False


# This function will validate login form data(email id,password)
# This can be used for employer signup form(because we are taking same data(email_id,password) while signup)
def validate_login_form(data):
    email_id = data['email_id']
    password = data['password']
    if is_email_valid(email_id):
        if is_password_valid(password):
            return {"status": True, "reason": ""}
        else:
            return {"status": False, "reason": Message["JOB_SEEKER_LOGIN"]["PASSWORD_IS_NOT_MATCHING_STANDARDS"]}
    else:
        return {"status": False, "reason": "EMAIL_ID_IS_INVALID"}


# This function will send emails to users
def send_email(subject, body, frm, to):
    send_mail(subject, '', 'noreply@shenzyn.com', to, html_message=body)


# This is a function to generate a random number for OTP
def get_random_number():
    return random.randint(1000, 9999)


def get_symbol():
    return random.choice(["-", "_", "@", ".", ""])


def get_urls(search, first_name, last_name, id, number):
    items = [search, first_name, last_name, number, get_random_number()]
    number_choice = random.choice([2, 3])
    data = random.choices(items, k=number_choice)
    return str(data[0])+str(get_symbol())+str(data[1])


def validate_url(url):
    import validators
    if validators.url(url):
        return True
    else:
        return False


def get_my_key(obj):
    return obj['parent_key']