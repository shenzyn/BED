# test = {
#     "base_url":"https://test.shenzyn.com",
#     "db_user" :"root",
#     "db_password" : "root",
#     "db_name": "shenzyn",
#	  "api_base_url":"https://test-api.shenzyn.com"
# }

# dev = {
#     "base_url":"https://dev.shenzyn.com",
#	  "api_base_url":"https://dev-api.shenzyn.com",	
#     "db_user" :"root",
#     "db_password" : "root",
#     "db_name": "shenzyn"
# }

server_settings = {
      "base_url": "https://dev.shenzyn.com",
      "db_user": "root",
      "db_password": "",
      "db_name": "shenzyn",
      "api_base_url": "https://dev-api.shenzyn.com"
}

# server_settings = {
#     "base_url":"https://dev.shenzyn.com",
#     "db_user" :"root",
#     "db_password" : "root",
#     "db_name": "shenzyn2",
#     "client_id":"81bydvlq8vfgo4",
#     "client_secret":"Qs28zBcDVtQU04O2",
#     "api_base_url":"https://test-api.shenzyn.com"
# }
# server_settings = {
#     "base_url": "https://dev.shenzyn.com",
#      "db_user": "root",
#      "db_password": "root",
#      "db_name": "shenzyn4",
#      "client_id": "81bydvlq8vfgo4",
#      "client_secret": "Qs28zBcDVtQU04O2",
#      "api_base_url": "https://dev-api.shenzyn.com"
#
# }

# Sahil Backend
# server_settings = {
#     "base_url": "https://test.shenzyn.com",
#     "db_user": "root",
#     "db_password": "root",
#     "db_name": "shenzyn2",
#     "client_id": "81bydvlq8vfgo4",
#     "client_secret": "Qs28zBcDVtQU04O2",
#     "api_base_url": "https://test-api.shenzyn.com"
# }
# server_settings = {
#     "base_url": "https://dev.shenzyn.com",
#     "db_user": "root",
#     "db_password": "root",
#     "db_name": "shenzyn4",
#     "client_id": "81bydvlq8vfgo4",
#     "client_secret": "Qs28zBcDVtQU04O2",
#     "api_base_url": "https://dev-api.shenzyn.com"
# }
