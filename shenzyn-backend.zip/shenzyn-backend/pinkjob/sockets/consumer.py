from asgiref.sync import async_to_sync
from channels.generic.websocket import AsyncJsonWebsocketConsumer

consumer_list = {}


class ApplicationCountConsumer(AsyncJsonWebsocketConsumer):
	async def connect(self):
		print("connected")
		await self.accept()

	async def receive_json(self, content, **kwargs):
		print('receiving', content)
		user = content['user_id']
		self.scope['poster'] = user
		if user in consumer_list:
			consumer_list[user].append(self)
		else:
			consumer_list[user] = [self]

	@async_to_sync
	async def websocket_send(self, data):
		print(data)
		await self.send_json(data)

	async def disconnect(self, code):
		print('disconnected', code)
		user = self.scope["poster"]
		consumer_list[user].remove(self)
		await self.close()
