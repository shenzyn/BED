"""pinkjob URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from django.contrib.auth import views
from django.conf import settings
from django.conf.urls.static import static

# Job seeker registration and Login base urls
urlpatterns = [
    path('pinkjob/admin/', admin.site.urls),
    path('pinkjob/job-seeker-registration/', include('job_seeker.job_seeker_registration.urls')),
    path('pinkjob/job-seeker-login/', include('job_seeker.job_seeker_login.urls')),
]

# employer Registration and Login Page Base Url
urlpatterns += [
    path('pinkjob/employer-registration/', include('employer.employer_registration.urls')),
    path('pinkjob/employer-login/', include('employer.employer_login.login_urls')),
    path('pinkjob/employer-login/account/', include('allauth.urls')),
    path('pinkjob/employer-login/gmail/', include('employer.employer_login.gmailAuthenticationUrl'))
]

# employer Homepage base url
urlpatterns += [
    path('pinkjob/employer-homepage/', include('employer.employer_homepage.homepage_urls')),
    path('pinkjob/account-settings/', include('employer.account_settings.account_settings_urls'))
]

# sub-users base url
urlpatterns += [
    path('pinkjob/sub_user/', include('employer.sub_user.urls'))
]


#  Post Jobs base url
urlpatterns += [
    path('pinkjob/post-jobs/', include('employer.post_jobs.post_jobs_urls'))
]

# Jobs Listing base Url
urlpatterns += [
    path('pinkjob/job-listing/', include('job_seeker.job_listing.job_listing_urls')),
    path('pinkjob/job-seeker/', include('job_seeker.job_application_status.application_status_urls'))
]

# Employer Inbox base URL
urlpatterns += [
    path('pinkjob/employer-inbox/', include('employer.employer_inbox.inbox_urls'))
]


if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
