
def validate_file_size(value, limit):
    filesize = value.size
    if filesize > limit:
        return True
    else:
        return False