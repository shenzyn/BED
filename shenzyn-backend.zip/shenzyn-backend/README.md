# Shenzyn



## Clone

Use the below command for clone the project.

```bash
git clone https://gitlab.com/selektin/pink-jobs-backend.git
```


# How to install virtualenv:

### Install **pip** first

    sudo apt-get install python3-pip

### Then install **virtualenv** using pip3

    sudo pip3 install virtualenv 

### Now create a virtual environment 

    virtualenv venv 

>you can use any name insted of **venv**

### You can also use a Python interpreter of your choice

    virtualenv -p /usr/bin/python2.7 venv
  
### Active your virtual environment:    
    
    source venv/bin/activate
    
### Using fish shell:    
    
    source venv/bin/activate.fish

### To deactivate:

    deactivate

### Create virtualenv using Python3
    virtualenv -p python3 myenv

### Instead of using virtualenv you can use this command in Python3
    python3 -m venv myenv

### change server_setting.py according to your database design and your local ip



### activate virtual venv and then install *requirements.txt:

    pip install -r requirements.txt
    pip install -r gupta_requirements.txt
    pip install -r sahil_requirements.txt


