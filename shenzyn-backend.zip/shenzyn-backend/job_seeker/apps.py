from django.apps import AppConfig


class JobSeekerConfig(AppConfig):
    name = 'job_seeker'
