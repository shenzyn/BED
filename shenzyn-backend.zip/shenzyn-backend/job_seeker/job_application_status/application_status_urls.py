from django.urls import path, include
from .application_status_view import *

urlpatterns = [
	# JobApplicationStatus API
	path('check-application-status/', CheckAllApplicationStatus.as_view()),
]
