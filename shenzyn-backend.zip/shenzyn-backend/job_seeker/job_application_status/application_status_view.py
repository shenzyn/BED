from rest_framework.views import APIView
from django.db.models import Q
from employer.decorators import *
from pinkjob.utils import Message
from datetime import datetime, timedelta
from employer.employer_inbox.inbox_models import JobApplications
from employer.post_jobs.post_jobs_models import PostJobs, JobLocations, AdvertiseCompanyDetailsJobMapping
from employer.employer_homepage.homepage_models import EmployerHiringOrganizationsMapping
from django.db import connection

# This will fetch all applications status
class CheckAllApplicationStatus(APIView):
	@permission_required()
	def post(self, request):
		# Initial placeholder for class variables
		# user_id, user_type = 1, 2
		status, message, data, count = False, "", [], 0
		try:
			# Fetching id and type from request token
			user_id, user_type = request.META["user_id"], request.META["user_type"]
			req = request.data
			print(req)
			# Initial checking if the received REQUEST contains all required parameters
			if ((req == []) or (
					not all(
						key in req for key in
						("status", "from", "to", "page", "limit", "sort")))):
				message = Message["EMPLOYER_INBOX"]["INVALID_REQUEST"]
			else:
				stat, start_date, end_date, page, limit, sort_order = req["status"], req["from"], req["to"],\
																		req["page"], req["limit"], req["sort"]
				# Checking the request data validation clause
				if (start_date > end_date) or (start_date != "" and end_date == "") or (
						start_date == "" and end_date != "") or type(start_date) != type(end_date):
					message = "Kindly select valid date range"
				# Making initial fetch query
				date_limit = datetime.now() - timedelta(days=90);
				print(user_id)
				job_application_query = JobApplications.objects.filter(Q(user_account_id__id=user_id))
				print(job_application_query,len(job_application_query))
				# Checking if some results are still remaining or not after all the previous filtering
				if len(job_application_query) == 0:
					message = "No such job application exists!"
				else:
					if start_date != "":
						start_date, end_date = datetime.fromtimestamp(start_date/1000.), datetime.date(datetime.fromtimestamp(
							end_date/1000.))+timedelta(1)
						if datetime.date(start_date) < datetime.date(datetime.now()) - timedelta(days=90):
							message = "You can only check applications from 90 days ago!"
							job_application_query = []
						else:
							job_application_query = job_application_query.filter(application_date__range=(
								start_date, end_date))
					# Checking if some results are still remaining or not after all the previous filtering
					print(job_application_query,len(job_application_query))
					if len(job_application_query) == 0:
						message = "No such job application exists!"
					else:
						# Filtering based on status
						if len(stat) != 0:
							stat = [i["key"] for i in stat]
							job_application_query = job_application_query.filter(
								job_application_status_id__id__in=stat)
						# Checking if some results are still remaining or not after all the previous filtering
						print(job_application_query,len(job_application_query))
						if len(job_application_query) == 0:
							message = "No such job application exists!"
						else:
							filtered_jobs_id = [i.job_id.id for i in job_application_query]
							# Attaching details of all filtered jobs
							for i in range(0,len(filtered_jobs_id)):
								job = filtered_jobs_id[i];
								print(job,"ascfno")
								chunk = {}
								job_details = PostJobs.objects.filter(id=job)[0]
								print(job_details,"job_details",job)
								application_details = job_application_query.filter(job_id__id=job)[0]
								print(application_details,"application_details")
								location_info = JobLocations.objects.filter(job_id__id=job)
								print(location_info,"111111111111")
								advertising_company_detail = AdvertiseCompanyDetailsJobMapping.objects.filter(
									job_id__id=job)[0]
								print(advertising_company_detail,"22222222222222")
								recruiting_company_detail = EmployerHiringOrganizationsMapping.objects.filter(
									user_account_id__id=job_details.user_account_id.id).first()
								print(recruiting_company_detail,"33333333333")
								query = "select count(id) as count_applied from employer_jobapplications where user_account_id_id = "+str(user_id)+" and job_id_id in (select id from employer_postjobs where user_account_id_id = (select user_account_id_id from employer_postjobs where id ="+str(job)+")) union all select count(id) as count_posted from employer_postjobs where status='Post' and user_account_id_id = (select user_account_id_id from employer_postjobs where id ="+str(job)+")"
								query_result = raw_query_execute_function(query)
								print(query_result);
								aplied_jobs = query_result[0][0] if query_result and len(query_result) > 0 and len(query_result[0]) > 0 else 0 ; 
								posted_jobs = query_result[1][0] if query_result and len(query_result) > 1 and len(query_result[1]) > 0 else 0;
								chunk["job_id"] = job
								chunk["job_title"] = job_details.job_title
								#chunk["location"] =[]
								chunk["location"] = [location_info[0].city_id.city+", "+location_info[0].country_id.country]
								# for location in location_info:
								# 	chunk["location"].append(location.city_id.city + ", " + location.country_id.country)
								chunk["company"] = advertising_company_detail.advertise_company_details_id\
									.organisation_name.name
								chunk["applied_on"] = application_details.application_date
								chunk["status"] = application_details.job_application_status_id.status
								chunk["recruiter_name"] = job_details.user_account_id.first_name + " " + job_details\
									.user_account_id.last_name
								chunk["recruiting_company"] = recruiting_company_detail.organiztion_id.name if recruiting_company_detail else "";
								chunk["posted_job"] = str(aplied_jobs) +"/"+str(posted_jobs)
								data.append(chunk)
							# Count of all finalised data
							count = len(data)
							# Slicing the result for pagination sake
							data = data[(page - 1) * limit: page * limit]
							# Ordering the result in descending value of date of publish of job
							data = sorted(data, key=lambda i: i["applied_on"], reverse=sort_order)
							# On reaching this point, the operation was successful
							status, message = True, Message["EMPLOYER_INBOX"]["SUCCESS"]
		except Exception as e:
			# Any runtime exception is caught and thrown here
			print(e)
			traceback.printexec()
			message = format(e)
		finally:
			# Ultimately the response is sent with appropriate operation success status and explanation message
			# along with finalised data and total count
			return Response({"status": status, "message": message, "data": data, "count": count}, status=200)

# This function used to excecute raw query in database
# So we have just send query and it will return probable result
def raw_query_execute_function(query):
	cursor = connection.cursor()
	cursor.execute(query)
	return cursor.fetchall()
