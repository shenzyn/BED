from rest_framework import serializers
from employer.post_jobs.post_jobs_serializers import *
from employer.employer_homepage.homepage_models import *
from .job_listing_models import *


class SearchJobsSerializer(serializers.ModelSerializer):
    job_id_skill = SearchDesireCandidateProfileSkillsSerializer(many=True)
    job_id_location = SearchJobLocationsSerialiser(many=True)
    job_id_post_questionnaire = SearchJobPostQuestionnaireSerialiser(many=True)
    post_jobs_advertise_id = SearchAdvertiseCompanyDetailsJobMappingSerialiser(many=True)

    class Meta:
        model = PostJobs
        fields = ("id", "job_id_skill", "job_id_location", "job_id_post_questionnaire", "post_jobs_advertise_id",
                  "job_title", "job_description", "min_experience", "max_experience", "min_salary",
                  "max_salary","is_salary_visible", "currency", "job_role", "created_on", "industries_id", "functional_area_id", "user_account_id")
        depth = 2


class AboutEmployerSerialiser(serializers.ModelSerializer):
    class Meta:
        model = AboutEmployer
        fields = '__all__'


class PostedBySerializer(serializers.ModelSerializer):
    employer_profile_id_about = AboutEmployerSerialiser(many=True)

    class Meta:
        model = EmployerProfile
        fields = '__all__'


class PreviewJobsSerializer(serializers.ModelSerializer):
    job_id_skill = SearchDesireCandidateProfileSkillsSerializer(many=True)
    job_id_location = SearchJobLocationsSerialiser(many=True)
    job_id_post_questionnaire = SearchJobPostQuestionnaireSerialiser(many=True)
    post_jobs_advertise_id = SearchAdvertiseCompanyDetailsJobMappingSerialiser(many=True)
    job_id_time = SearchWorkingHoursSerializer(many=True)
    job_id_walkin = SearchWalkinDetailsSerialiser(many=True)
    job_id_qualification1 = SearchJobRequiredQualificationsSerializer(many=True)
    job_id_qualification2 = SearchPHDJobRequiredQualificationsSerializer(many=True)
    job_id_hide_or_show = SearchShowOrHideOrganisationsSerialiser(many=True)

    class Meta:
        model = PostJobs
        fields = "__all__"
        depth = 2


class GetSavedJobsSerialiser(serializers.ModelSerializer):
    class Meta:
        model = SavedJobs
        fields = "__all__"
        depth = 2