from elasticsearch import Elasticsearch
from .job_listing_views import *
import pdb

HOST_URLs = ["http://127.0.0.1:9200"]
# es = Elasticsearch([{"host" : "localhost", "port" : 9200}])
es = Elasticsearch(HOST_URLs)

e1 = {"id":1,"value" : "data to be not inserted"}


def insert_in_es(e1):
    res = es.index(index="elasticsearch", doc_type="job_post", id=e1["id"], body=e1)
    return res


def insert_multi_in_es(e1):
    for values in e1:
        res = es.index(index="elasticsearch", doc_type="job_post", id=values["id"], body=values)
    return res


def delete_from_es(id):
    res= es.delete(index="elasticsearch", doc_type="job_post", id=id)
    return res


def search_in_es(query):
    out = []
    res = es.search(index="elasticsearch", body={'size':10000,'query' : {'bool' : {'should' : query}}})
    for hit in res['hits']['hits']:
        out.append(hit['_id'])
        # chunk = {}
        # chunk['value'] = hit['_source']['value']
        # chunk['id'] = hit['_id']
        # chunk["score"] = hit['_score']
        # out.append(chunk)
    return out


def remove_deuplicate(array):
    result = ""
    data = array.split(", ")
    data = list(set(data))
    for dat in data:
        result += dat + ", "
    return result if result == "" else result[:-2]


def create_string_in_elastic_search(data_id):
    try:
        result = []
        post_jobs_queryset = raw_query_execute_function("select employer_postjobs.id , employer_postjobs.job_title, employer_postjobs.job_description, employer_postjobs.min_experience, employer_postjobs.max_experience, employer_postjobs.min_salary, employer_postjobs.max_salary, employer_postjobs.how_soon_required, employer_postjobs.type_of_job, tx.website_url, tx.name, tx.organisation_description, sk.skill_set_name, lc.city, pm.phd_major, nm.major, ps.phd_spec, ns.spec from employer_postjobs left join (select employer_advertisecompanydetails.organisation_description, employer_advertisecompanydetails.website_url, employer_advertisecompanydetailsjobmapping.job_id_id, employer_organizations.name from employer_advertisecompanydetails, employer_advertisecompanydetailsjobmapping, employer_organizations where employer_advertisecompanydetails.id = employer_advertisecompanydetailsjobmapping.advertise_company_details_id_id and employer_organizations.id = employer_advertisecompanydetails.organisation_name_id ) as tx on tx.job_id_id=employer_postjobs.id left join (select job_seeker_skillset.skill_set_name, employer_desirecandidateprofileskills.job_id_id from job_seeker_skillset, employer_desirecandidateprofileskills where employer_desirecandidateprofileskills.qualities_id = job_seeker_skillset.id) as sk on sk.job_id_id=employer_postjobs.id left join (select job_seeker_location.city, employer_joblocations.job_id_id from employer_joblocations, job_seeker_location where employer_joblocations.city_id_id = job_seeker_location.id) as lc on lc.job_id_id=employer_postjobs.id left join (select distinct job_seeker_majors.major_name as phd_major, employer_jobrequiredphdqualifications.job_id_id from  job_seeker_majors, employer_jobrequiredphdqualifications where employer_jobrequiredphdqualifications.phd_major_id_id = job_seeker_majors.id) as pm on pm.job_id_id = employer_postjobs.id left join (select distinct job_seeker_majors.major_name as major, employer_jobrequiredqualifications.job_id_id from  job_seeker_majors, employer_jobrequiredqualifications where  employer_jobrequiredqualifications.major_id_id = job_seeker_majors.id) as nm on nm.job_id_id = employer_postjobs.id left join (select distinct job_seeker_specializations.specialization_name as phd_spec, employer_jobrequiredphdqualifications.job_id_id from  job_seeker_specializations, employer_jobrequiredphdqualifications where employer_jobrequiredphdqualifications.phd_specialization_id_id = job_seeker_specializations.id) as ps on ps.job_id_id = employer_postjobs.id left join (select distinct job_seeker_specializations.specialization_name as spec, employer_jobrequiredqualifications.job_id_id from  job_seeker_specializations, employer_jobrequiredqualifications where  employer_jobrequiredqualifications.specialization_id_id = job_seeker_specializations.id) as ns on ns.job_id_id = employer_postjobs.id where employer_postjobs.id = "+data_id+";")
        for values in post_jobs_queryset:
            string, flag = "", False
            string += values[1] + ", " if values[1] != None and values[1] != "" else ""
            string += values[2] + ", " if values[2] != None and values[2] != "" else ""
            string += str(values[3]) + ", " if values[3] != None and values[3] != "" else ""
            string += str(values[4]) + ", " if values[4] != None and values[4] != "" else ""
            string += str(values[5]) + ", " if values[5] != None and values[5] != "" else ""
            string += str(values[6]) + ", " if values[6] != None and values[6] != "" else ""
            string += values[7] + ", " if values[7] != None and values[7] != "" else ""
            string += values[8] + ", " if values[8] != None and values[8] != "" else ""
            string += values[9] + ", " if values[9] != None and values[9] != "" else ""
            string += values[10] + ", " if values[10] != None and values[10] != "" else ""
            string += values[11] + ", " if values[11] != None and values[11] != "" else ""
            string += values[12] + ", " if values[12] != None and values[12] != "" else ""
            string += values[13] + ", " if values[13] != None and values[13] != "" else ""
            string += values[14] + ", " if values[14] != None and values[14] != "" else ""
            string += values[15] + ", " if values[15] != None and values[15] != "" else ""
            string += values[16] + ", " if values[16] != None and values[16] != "" else ""
            string += values[17] + ", " if values[17] != None and values[17] != "" else ""
            for data in result:
                if data["id"] == values[0]:
                    data["string"] += ", "+ string[:-2]
                    flag = True
            if not flag:
                result.append({"id":values[0],"string":string[:-2]})
        for values in result:
            values["string"] = remove_deuplicate(values["string"])
        print(result)
        return insert_in_es(result[0])
    except Exception as e:
        return format(e)


