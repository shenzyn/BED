from django.db import models
from employer.models import UserAccount
from employer.post_jobs.post_jobs_models import PostJobs, Questions, OptionValues
from employer.employer_inbox.inbox_models import JobApplications, JobApplicationStatus


class SavedJobs(models.Model):
    job_id= models.ForeignKey(PostJobs, related_name="job_id_saved", on_delete=models.CASCADE, null=True)
    user_id= models.ForeignKey(UserAccount, related_name="user_id_saved", on_delete=models.CASCADE, null=True)


class SavedQuestionnaireResponse(models.Model):
    application_id = models.ForeignKey(JobApplications, related_name="saved_responses_application_id", on_delete=models.CASCADE, null=True)
    question_id = models.ForeignKey(Questions, related_name="saved_response_question_id", on_delete=models.CASCADE, null=True)
    answer = models.TextField(null=True)
