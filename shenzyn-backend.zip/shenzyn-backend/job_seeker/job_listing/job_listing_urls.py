# This file contains urls for Job listing.
# The followings are child urls for base url(/job-listing/)
# by using following url path the specified functions are runs.

from django.urls import path, include
from .job_listing_views import *

# this are all /job-listing/ api listed here with function name
urlpatterns = [
    path('get-skill-company-designation/', GetDesignationSkillCompany.as_view()),
    path('search-jobs/', SearchJobs.as_view()),
    path('save-jobs/', SaveJobs.as_view()),
    path('get-saved-jobs/', GetSavedJobs.as_view()),
    path('quick-apply-jobs/', QuickApplyJobs.as_view()),
    path('get-applied-jobs/', GetAppliedJobs.as_view()),
    path('preview-jobs/', PreviewJobs.as_view()),
    path('search-text/', SearchText.as_view()),
    path('get-questionnaire/', GetQuestionnaire.as_view())
]
