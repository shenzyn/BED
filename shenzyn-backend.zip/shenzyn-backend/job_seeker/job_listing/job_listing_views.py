# All employer registration APIViews will be in this file
from rest_framework.views import APIView
from pinkjob.server_settings import *
from django.db import connection
from django.db.models import Q
from employer.decorators import *
from employer.post_jobs.post_jobs_models import *
from employer.employer_homepage.homepage_models import Organizations
from employer.employer_homepage.homepage_models import *
from .job_listing_serializers import SearchJobsSerializer, PostedBySerializer, PreviewJobsSerializer, \
	GetSavedJobsSerialiser
from .job_listing_models import SavedJobs, SavedQuestionnaireResponse, JobApplications, JobApplicationStatus
# from employer.post_jobs.post_jobs_views import *
from employer.post_jobs.post_jobs_serializers import SearchPostJobsSerializer_1
from pinkjob.utils import *
import datetime
import math
import collections
from job_seeker.models import *
from pinkjob.sockets.consumer import consumer_list
import pdb
import time
import traceback

base_url = server_settings["base_url"]


# This function used get Designations, skills and company names for job search modules
# This api gives all values withe key and there type
class GetDesignationSkillCompany(APIView):
	def get(self, request):
		try:
			if 'search' not in request.GET:
				return Response(
					{"status": False, "message": Message["JOB_LISTING"]["GET_DESIGNATION_SKILL_COMPANY_ERROR"]},
					status=200)
			search, data = request.GET["search"], []
			designation_queryset = Designation.objects.filter(name__icontains=search)[:10]
			skill_set_queryset = SkillSet.objects.filter(skill_set_name__icontains=search)[:10]
			organisation_queryset = Organizations.objects.filter(name__icontains=search)[:10]
			print(designation_queryset, skill_set_queryset, organisation_queryset)
			for value in skill_set_queryset:
				data.append({"value": value.skill_set_name, "key": value.id, "type": "skill"})
			for value in designation_queryset:
				data.append({"value": value.name, "key": value.id, "type": "designation"})
			for value in organisation_queryset:
				data.append({"value": value.name, "key": value.id, "type": "company"})
			return Response(
				{"status": False, "message": Message["JOB_LISTING"]["GET_DESIGNATION_SKILL_COMPANY_SUCCESS"],
				 "data": data}, status=200)
		except Exception as e:
			return Response({"status": False, "message": format(e)}, status=200)


# This function use to get search jobs api result
# User can send normal or advanced search parameters and depending on parameters following functions gives result
# This API function divided into sub functions depending on there functionality
class SearchJobs(APIView):
	# This calculates the matching percentage from the details from the appliers data and job description
	def percentage_calculator(self, values, data):
		# print(values, data)
		skill_percentage, exp_percentage, salary_percentage = 0, 0, 0
		job_skills = [d["qualities"]["key"] for d in values["job_id_skill"]]
		print(data["skill_designation_com"], "skill_designation_com Here")
		my_skills = []
		# my_skills = data["skill_designation_com"].split(', ')
		# my_skills = [d["key"] for d in data["skill_designation_com"]]
		# if len(my_skills) == 0:
		# print(my_skills)
		user_skills = SeekerSkillSet.objects.filter(user_account_id__id=data['user_id'])
		if len(user_skills) != 0:
			my_skills = [user_skill.skill_set_id.id for user_skill in user_skills]
		print("Skills Here", job_skills, my_skills, data['user_id'])
		matched_skill = list(set(job_skills) & set(my_skills))
		# Calculating ratio of matched skill by total skills
		skill_percentage = (len(matched_skill) / len(job_skills)) * 50
		# Calculating maximum and minimum salary relation with expected salary
		if data["min_exp"] != "":
			if int(data["min_exp"]) < values["min_experience"] and ((
							values["max_experience"] - values["min_experience"]) != 0):
				exp_percentage = ((values["max_experience"] - int(data["min_exp"])) / (
							values["max_experience"] - values["min_experience"])) * 20
			else:
				if int(data["min_exp"]) > values["max_experience"] and ((
								values["max_experience"] - values["min_experience"]) != 0):
					exp_percentage = ((int(data["min_exp"]) - values["max_experience"]) / (
								values["max_experience"] - values["min_experience"])) * 20
				else:
					exp_percentage = 20
		# Calculating maximum and minimum experience relation with expected experience
		if data["min_salary"] != "":
			if float(data["min_salary"]) < values["min_salary"] and ((
						values["max_salary"] - values["min_salary"]) != 0):
				salary_percentage = ((values["max_salary"] - float(data["min_salary"])) / (
						values["max_salary"] - values["min_salary"])) * 20
			else:
				if float(data["min_salary"]) > values["max_salary"] and ((
							values["max_salary"] - values["min_salary"]) != 0):
					salary_percentage = (float((data["min_salary"]) - values["max_salary"]) / (
							values["max_salary"] - values["min_salary"])) * 20
				else:
					salary_percentage = 20
		# print(skill_percentage + exp_percentage + salary_percentage, "<<<<<<<<<<<<<<<RESULT")
		return skill_percentage + exp_percentage + salary_percentage

	# This filter by count function used to give count of each filtered by options related with search result
	def filter_by_count(self, array):
		names, final = [], []
		for values in array:
			names.append(values["name"])
		counter = collections.Counter(names)
		for values in counter:
			for val in array:
				if val["name"] is values:
					final.append({"name": values, "count": counter[values], "key": val["key"]})
					break
		return final

	# This filter_by_function use to construct a filter  by response related to search api
	def filter_by_function(self, seialiser_data):
		filter_by, location, skill, designation, company, salary, experience, func, ind = [], [], [], [], [], [], [], [], []
		for values in seialiser_data:
			print(values["industries_id"])
			if values["functional_area_id"]:
				func.append({"name": values["functional_area_id"]["name"], "key": values["functional_area_id"]["id"]})
			if values["industries_id"]:
				ind.append({"name": values["industries_id"]["name"], "key": values["industries_id"]["id"]})
			for data in values["job_id_location"]:
				location.append({"name": data["city_id"]["city"], "key": data["city_id"]["id"]})
			for data in values["job_id_skill"]:
				skill.append({"name": data["qualities"]["value"], "key": data["qualities"]["key"]})
			if values["job_role"]:
				designation.append({"name": values["job_role"]["name"], "key": values["job_role"]["id"]})
			if values["post_jobs_advertise_id"]:
				company.append(
					values["post_jobs_advertise_id"][0]["advertise_company_details_id"]["organisation_name"]["name"])
			if values["is_salary_visible"]:
				salary.append({"name": str(values["min_salary"]) + " - " + str(values["max_salary"]), "key": 1})
			experience.append({"name": str(values["min_experience"]) + " - " + str(values["max_experience"]), "key": 1})
		"" if location == [] else filter_by.append({"title": "Location", "values": self.filter_by_count(location)})
		"" if skill == [] else filter_by.append({"title": "Skill", "values": self.filter_by_count(skill)})
		"" if designation == [] else filter_by.append(
			{"title": "Designation", "values": self.filter_by_count(designation)})
		"" if salary == [] else filter_by.append({"title": "Salary", "values": self.filter_by_count(salary)})
		"" if experience == [] else filter_by.append(
			{"title": "Experience", "values": self.filter_by_count(experience)})
		"" if ind == [] else filter_by.append({"title": "Industry", "values": self.filter_by_count(ind)})
		"" if func == [] else filter_by.append({"title": "Functional Area", "values": self.filter_by_count(func)})
		return filter_by

	# This response data function create result response depending on data fetch from database filter by given ids
	def response_data(self, ids, user_data):
		response_ = []
		postjob_queryset = PostJobs.objects.filter(id__in=ids).order_by("-created_on")
		serialiser_searchjobs = SearchJobsSerializer(postjob_queryset, many=True).data
		for values in serialiser_searchjobs:
			# print(values)
			location, skills = "", ""
			for data in values["job_id_location"]:
				location += str(data["city_id"]["city"]) + ", "
			for data in values["job_id_skill"]:
				skills += str(data["qualities"]["value"]) + ", "
			skills = skills[:-2] if skills is not "" else skills
			location = location[:-2] if location is not "" else location
			print(values["created_on"])
			response_format = {
				"job_title": values["job_title"],
				"job_Role": values["job_role"]["name"] if values["job_role"] else "",
				"company_name":
					values["post_jobs_advertise_id"][0]["advertise_company_details_id"]["organisation_name"]["name"] if
					values["post_jobs_advertise_id"] else "",
				"experience_details": str(values["min_experience"]) + " - " + str(values["max_experience"]),
				"location": location,
				"expected_salary": values["currency"]["code"] + " " + str(values["min_salary"]) + " - " + str(values["max_salary"]) + " lacs" if values[
																										"is_salary_visible"] is False else "Not Disclosed",
				"job_description": values["job_description"],
				"skills": skills,
				"posted_by": "Posted by " + self.get_posted_by_names(
					values["user_account_id"]["id"]) + " on " + datetime.datetime.strptime(values["created_on"],
																						   '%Y-%m-%dT%H:%M:%S.%fZ').strftime(
					"%d %b %Y"),
				"is_questionnaire": True if values["job_id_post_questionnaire"] else False,
				"questionnaire_id": values["job_id_post_questionnaire"] if values["job_id_post_questionnaire"] else "",
				"key": values["id"],
				"match": self.percentage_calculator(values, user_data)
			}
			stat_query = JobApplications.objects.filter(Q(user_account_id__id=user_data["user_id"]) & Q(job_id__id=values["id"]))
			stat = "Apply"
			if len(stat_query) != 0:
				stat = stat_query[0].job_application_status_id.status
			response_format["application_status"] = stat
			job_desc_docs = {}
			description_documents = JobDescriptionDocuments.objects.filter(job_id__id=values['id'])
			print(len(description_documents))
			if len(description_documents) != 0 and description_documents:
				job_desc_docs = {
					"video": postjob_queryset[0].video_description.url if postjob_queryset[0].video_description else "",
					"video_updated_on": postjob_queryset[0].video_updated_on,
					"document_1": description_documents[0].document_1.url if description_documents[0] and description_documents[0].document_1 else "" ,
					"document_1_updated_on": description_documents[0].document_1_updated_on if description_documents[0].document_1_updated_on else "",
					"document_2": description_documents[0].document_2.url if description_documents[0] and description_documents[0].document_2 else "",
					"document_2_updated_on": description_documents[0].document_2_updated_on if description_documents[0].document_2_updated_on else "",
					"document_3": description_documents[0].document_3.url if description_documents[0] and description_documents[0].document_3 else "",
					"document_3_updated_on": description_documents[0].document_3_updated_on if description_documents[0].document_3_updated_on else "",
					"document_4": description_documents[0].document_4.url if description_documents[0] and description_documents[0].document_4 else "",
					"document_4_updated_on": description_documents[0].document_4_updated_on if description_documents[0].document_4_updated_on else "",
					"document_5": description_documents[0].document_5.url if description_documents[0] and description_documents[0].document_4 else "",
					"document_5_updated_on": description_documents[0].document_5_updated_on if description_documents[0].document_5_updated_on else ""
				}
				job_desc_docs["video"] = job_desc_docs["video"].split("pinkjob/media/")[1].replace("%3A",":/") if job_desc_docs["video"].__contains__("shenzyn.com") else job_desc_docs["video"]; 
			response_format["job_description_documents"] = job_desc_docs
			response_.append(response_format)

		return {"result": response_, "filter_by": self.filter_by_function(serialiser_searchjobs)}

	# This function used by advanced search to create raw query depending upon requested data
	def advanced_search(self, data):
		from .elastic_search import search_in_es
		tables, condition, condition2, location, skill, role, comp, ids, indu, func_area = "employer_postjobs", "", "", "", "", "", "", [], "", ""
		if data["skill_designation_com"]:
			dummy = data["skill_designation_com"].split(", ")
			val = []
			for values in dummy:
				val.append({'match': {"string": values}})
			if val != []:
				print(val)
				id = tuple(search_in_es(val))
				id = str(id).replace(',)', ')')
				print(id)
				if str(id) != "()":
					print("passed?", id)
					condition += "employer_postjobs.id in " + str(id) + " and "
		for values in data["location"]:
			location += str(values["key"]) + ", "
		for values in data["industry"]:
			indu += str(values["key"]) + ", "
		for values in data["functional_area"]:
			func_area += str(values["key"]) + ", "
		if data["min_exp"] is not "":
			condition += "((employer_postjobs.min_experience<=" + str(
				data["min_exp"]) + " and employer_postjobs.max_experience>=" + str(
				data["min_exp"]) + ") or (employer_postjobs.min_experience<=" + str(
				data["max_exp"]) + " and employer_postjobs.max_experience>=" + str(data["max_exp"]) + ")) and "
		if data["min_salary"] is not "":
			condition += "((employer_postjobs.min_salary<=" + str(
				data["min_salary"]) + " and employer_postjobs.max_salary>=" + str(
				data["min_salary"]) + ") or (employer_postjobs.min_salary<=" + str(
				data["max_salary"]) + " and employer_postjobs.max_salary>=" + str(data["max_salary"]) + ")) and  "
		print(location, data["location"])
		if location != "":
			location = location[:-2]
			tables += ", employer_joblocations"
			condition += "employer_joblocations.job_id_id = employer_postjobs.id and employer_joblocations.city_id_id in (" + location + ") and "
		if data["job_type"] != "":
			condition += "employer_postjobs.type_of_job='" + data["job_type"] + "' and "
		if indu != "":
			indu = indu[:-2]
			condition += "employer_postjobs.industries_id_id in (" + indu + ") and "
		if func_area != "":
			func_area = func_area[:-2]
			condition += "employer_postjobs.functional_area_id_id in (" + func_area + ") and "
		final_condition = condition[:-5]
		print(final_condition)
		if condition2 is not "":
			final_condition = condition[:-5] + " and (" + condition2[:-4] + ")"
		print(final_condition, condition, condition2)
		add_on_filter_by_query = self.filter_by_add_on_query(data)
		if final_condition != "" and final_condition[-4:-1] != "and":
			final_condition += ' and '
		if add_on_filter_by_query != "" and final_condition[-4:-1] != "and":
			print(add_on_filter_by_query, "<<<<<<<<<<<<<<<<<")
			final_condition += add_on_filter_by_query
			if "employer_joblocations" in add_on_filter_by_query:
				if "employer_joblocations" not in tables:
					tables += ", employer_joblocations"
			if "employer_desirecandidateprofileskills" in add_on_filter_by_query:
				if "employer_desirecandidateprofileskills" not in tables:
					tables += ", employer_desirecandidateprofileskills"
		if final_condition != "" and final_condition[-4:-1] != "and":
			print(final_condition, "see here")
			final_condition += " and "
		query = 'select distinct(employer_postjobs.id), employer_postjobs.created_on from ' + tables + ' where ' + final_condition + ' employer_postjobs.status = "Post" order by employer_postjobs.created_on desc;'
		print(query)
		query_result = raw_query_execute_function(query)
		for values in query_result:
			ids.append(values[0])
		ids = self.sort_result_as_per_limit(ids, data["result_per_page"], data["pagination"])
		result = self.response_data(ids, data)
		result["counts"] = self.result_count(query_result, data["result_per_page"])
		return result

	# This function used by normal search to create raw query depending upon requested data
	def normal_search(self, data):
		from .elastic_search import search_in_es
		tables, condition, condition2, location, skill, role, comp, ids = "employer_postjobs", "", "", "", "", "", "", []
		if data["skill_designation_com"]:
			dummy = data["skill_designation_com"].split(", ")
			val = []
			for values in dummy:
				val.append({'match': {"string": values}})
			if val != []:
				print(val)
				id = tuple(search_in_es(val))
				id = str(id).replace(',)', ')')
				print(id)
				if id != ():
					condition += "employer_postjobs.id in " + str(id) + " and "
		print(condition, "---------------------------")
		for values in data["location"]:
			location += str(values["key"]) + ", "
		if data["min_exp"] is not "":
			condition += "employer_postjobs.min_experience<=" + str(
				data["min_exp"]) + " and employer_postjobs.max_experience>=" + str(data["min_exp"]) + " and "
		if data["min_salary"] is not "":
			condition += "employer_postjobs.min_salary<=" + str(
				data["min_salary"]) + " and employer_postjobs.max_salary>=" + str(data["min_salary"]) + " and "
		print(condition)
		print(location, data["location"])
		if location != "":
			location = location[:-2]
			tables += ", employer_joblocations"
			condition += "employer_joblocations.job_id_id = employer_postjobs.id and employer_joblocations.city_id_id in (" + location + ") and "
		final_condition = condition[:-4]
		print(final_condition)
		if condition2 is not "":
			final_condition = condition[:-4] + " and (" + condition2[:-4] + ")"
		add_on_filter_by_query = self.filter_by_add_on_query(data)
		if final_condition != "" and final_condition[-4:-1] != "and":
			final_condition += ' and '
		print(final_condition)
		if add_on_filter_by_query != "":
			print(add_on_filter_by_query, "<<<<<<<<<<<<<<<<<")
			final_condition += add_on_filter_by_query
			if "employer_joblocations" in add_on_filter_by_query:
				if "employer_joblocations" not in tables:
					tables += ", employer_joblocations"
			if "employer_desirecandidateprofileskills" in add_on_filter_by_query:
				if "employer_desirecandidateprofileskills" not in tables:
					tables += ", employer_desirecandidateprofileskills"
		if final_condition != "" and final_condition[-4:-1] != "and":
			final_condition += " and "
		print(final_condition)
		query = 'select distinct(employer_postjobs.id), employer_postjobs.created_on from ' + tables + ' where ' + final_condition + ' employer_postjobs.status = "Post" order by employer_postjobs.created_on desc;'
		print(query)
		query_result = raw_query_execute_function(query)
		for values in query_result:
			ids.append(values[0])
		print(ids, query_result, query)
		ids = self.sort_result_as_per_limit(ids, data["result_per_page"], data["pagination"])
		result = self.response_data(ids, data)
		result["counts"] = self.result_count(query_result, data["result_per_page"])
		return result

	# This function use to create addition query when user select filter by option from job listed page
	def filter_by_add_on_query(self, data):
		condition, location, skill, designation, salary, exp, ind, func = "", "", "", "", "", "", "", ""
		if data["filter_by"]:
			for values in data["filter_by"]:
				if values["title"] == "Location":
					for loc in values["values"]:
						location += str(loc["key"]) + ", "
					if location is not "":
						location = location[:-2]
						condition += "employer_joblocations.city_id_id in (" + location + ") and "
				if values["title"] == "Skill":
					for value in values["values"]:
						skill += str(value["key"]) + ", "
					if skill is not "":
						skill = skill[:-2]
						condition += "employer_desirecandidateprofileskills.qualities_id in (" + skill + ") and "
				if values["title"] == "Designation":
					for value in values["values"]:
						designation += str(value["key"]) + ", "
					if designation is not "":
						designation = designation[:-2]
						condition += "employer_postjobs.job_role_id in (" + designation + ") and "
				if values["title"] == "Experience":
					for value in values["values"]:
						exp = value["name"].split(" - ")
						condition += "((employer_postjobs.min_experience<=" + exp[
							0] + " and employer_postjobs.max_experience>=" + exp[
										 0] + ") or (employer_postjobs.min_experience<=" + exp[
										 1] + " and employer_postjobs.max_experience>=" + exp[1] + ")) and "
				if values["title"] == "Salary":
					for value in values["values"]:
						salary = value["name"].split(" - ")
						condition += "((employer_postjobs.min_salary<=" + salary[
							0] + " and employer_postjobs.max_salary>=" + salary[
										 0] + ") or (employer_postjobs.min_salary<=" + salary[
										 1] + " and employer_postjobs.max_salary>=" + salary[1] + ")) and "
				if values["title"] == "Industry":
					for value in values["values"]:
						ind += str(value["key"]) + ", "
					if ind is not "":
						ind = ind[:-2]
						condition += "employer_postjobs.industries_id_id in (" + ind + ") and "
				if values["title"] == "Functional Area":
					for value in values["values"]:
						func += str(value["key"]) + ", "
					if func is not "":
						func = func[:-2]
						condition += "employer_postjobs.functional_area_id_id in (" + func + ") and "
		return condition[:-4] if condition is not "" else ""

	# This function used to send selected limit result
	# If user select only show 5 result then this function send only 5 result by every page
	def sort_result_as_per_limit(self, ids, result_per_page, pagination):
		ids = ids[((result_per_page * pagination) - result_per_page):(result_per_page * pagination)]
		return ids

	# This function used to get about employer deatils for posted by filed
	def get_posted_by_names(self, id):
		employer_queryset = EmployerProfile.objects.filter(user_account_id=id)
		serialiser_data = PostedBySerializer(employer_queryset, many=True).data
		name = ""
		if serialiser_data:
			for data in serialiser_data[0]["employer_profile_id_about"]:
				name = data["about_employer"]
		return name

	# This function used to count result and send it to frontend for showing total result
	def result_count(self, result, result_per_page):
		count = 0
		for values in result:
			if values[1].strftime("%x") == datetime.datetime.now().strftime("%x"):
				count += 1
		array_data = {"total_result": len(result), "applied_jobs_today": count,
					  "total_pagination": math.ceil(len(result) / result_per_page)}
		return array_data

	# This function used to send response to user
	# This function called another functions depend on search status
	@permission_required()
	def post(self, request):
		user_id, user_type = request.META["user_id"], request.META["user_type"]
		try:
			data = request.data
			data["user_id"] = user_id
			if data["is_advanced"]:
				return Response({"status": True, "message": Message["JOB_LISTING"]["SEARCH_JOBS_SUCCESS"],
								 "data": self.advanced_search(data)}, status=200)
			else:
				return Response({"status": True, "message": Message["JOB_LISTING"]["SEARCH_JOBS_SUCCESS"],
								 "data": self.normal_search(data)}, status=200)
		except Exception as e:
			traceback.print_exc()
			return Response({"status": False, "message": format(e)}, status=200)


# This is preview jobs function wherever user send selected job id
# This function send all details related to that selected job id for showing preview if that jobs
class PreviewJobs(APIView):
	@permission_required()
	def get(self, request):
		try:
			user_id, user_type = request.META["user_id"], request.META["user_type"]
			if 'id' not in request.GET:
				return Response({"status": False, "message": Message["JOB_LISTING"]["PREVIEW_JOB_ERROR"]}, status=200)
			id = request.GET["id"]
			application_query = JobApplications.objects.filter(Q(job_id__id=id) & Q(user_account_id__id=user_id))
			stat = "Apply"
			if len(application_query) != 0:
				stat = application_query[0].job_application_status_id.status
			postjob_queryset = PostJobs.objects.filter(id=id)
			serialiser_previewjobs = PreviewJobsSerializer(postjob_queryset, many=True).data
			for data in serialiser_previewjobs:
				print(data)
				location_object, working_objects, skill_objects, major_names, phd_majors_names, specialisation_names, phd_specialisation_names = [], [], [], "", "", "", ""
				questionnaire_object, spec_object, major_object, phd_spec_object, phd_major_object, org_object, is_show =  [], [], [], [], [], [], False
				for location_data in data["job_id_location"]:
					location_object.append({"country": {"key": location_data["country_id"]["id"], "value": location_data["country_id"]["country"]},
											"location": {"key": location_data["city_id"]["id"], "value": location_data["city_id"]["city"]}})
				for timings in data["job_id_time"]:
					working_objects.append({"shift": timings["time_type"], "start": timings["start_time"],
											"end": timings["end_time"]})
				for skill in data["job_id_skill"]:
					skill_objects.append({"key": skill["qualities"]["key"], "value": skill["qualities"]["value"], "match": False})
				skill_query = SeekerSkillSet.objects.filter(user_account_id__id=user_id)
				if len(skill_query) != 0:
					for skl in skill_query:
						for trgt_skl in skill_objects:
							if trgt_skl['key'] == skl.skill_set_id.id:
								trgt_skl['match'] = True
				# for city in data["job_id_location"]:
				# 	location += str(city["city_id"]["city"]) + ", "
				# for skill in data["job_id_skill"]:
				# 	skills += str(skill["qualities"]["value"]) + ", "
				# for timings in data["job_id_time"]:
				# 	timing.append(
				# 		timings["time_type"] + " Shift (" + timings["start_time"] + " - " + timings["end_time"] + ")")
				# for values in data["job_id_qualification2"]:
				# 	phd_majors_names += values["phd_major_id"]["major_name"] + ", "
				# 	phd_specialisation_names += values["phd_specialization_id"]["specialization_name"] + ", "
				# for values in data["job_id_qualification1"]:
				# 	major_names += values["major_id"]["major_name"] + ", "
				# 	specialisation_names += values["specialization_id"]["specialization_name"] + ", "
				previous_major_id, previous_major_id2 = 0, 0
				for spec_data in data["job_id_qualification1"]:
					if spec_data["major_id"]["id"] is not previous_major_id:
						major_object.append({"key":spec_data["major_id"]["id"],"value":spec_data["major_id"]["major_name"]})
						previous_major_id = spec_data["major_id"]["id"]
						spec_object.append({"parent_key":spec_data["major_id"]["id"], "key":spec_data["major_id"]["id"], "value":spec_data["major_id"]["major_name"], "is_parent":True})
					spec_object.append({"parent_key":spec_data["major_id"]["id"], "key":spec_data["specialization_id"]["id"], "value":spec_data["specialization_id"]["specialization_name"], "is_parent":False})
				for spec_data in data["job_id_qualification2"]:
					if spec_data["phd_major_id"]["id"] is not previous_major_id2:
						phd_major_object.append({"key":spec_data["phd_major_id"]["id"],"value":spec_data["phd_major_id"]["major_name"]})
						previous_major_id2 = spec_data["phd_major_id"]["id"]
						phd_spec_object.append({"parent_key":spec_data["phd_major_id"]["id"], "key":spec_data["phd_major_id"]["id"], "value":spec_data["phd_major_id"]["major_name"], "is_parent":True})
					phd_spec_object.append({"parent_key":spec_data["phd_major_id"]["id"], "key":spec_data["phd_specialization_id"]["id"], "value":spec_data["phd_specialization_id"]["specialization_name"], "is_parent":False})
				if len(data["job_id_hide_or_show"]) > 0:
					for org_data in data["job_id_hide_or_show"]:
						is_show = org_data["is_show"]
						org_object.append({"key":org_data["organisation_id"]["key"],"value":org_data["organisation_id"]["value"]})
				else:
					is_show = 2;
				questionnaire_queryset = JobPostQuestionnaire.objects.filter(job_id=data["id"])
				for questionnaire_data in questionnaire_queryset:
					questionnaire_object = {"key": questionnaire_data.questionnaire_id.id, "value": questionnaire_data.questionnaire_id.questionnaire_name}
				advertise_key = data["post_jobs_advertise_id"][0]["advertise_company_details_id"]["id"] if data["post_jobs_advertise_id"] else ""

				response_data = {
					# "about_job": {
					# 	"job_title": data["job_title"],
					# 	"job_Role": data["job_role"]["name"] if data["job_role"] else "",
					# 	"company_name":
					# 		data["post_jobs_advertise_id"][0]["advertise_company_details_id"]["organisation_name"][
					# 			"name"] if data["post_jobs_advertise_id"] else "",
					# 	"experience_details": str(data["min_experience"]) + " - " + str(data["max_experience"]),
					# 	"location": location[:-2] if location is not "" else location,
					# 	"expected_salary": str(data["min_salary"]) + " - " + str(data["max_salary"]) if data[
					# 																						"is_salary_visible"] is False else "Not Disclosed",
					# 	"job_description": data["job_description"],
					# 	"skills": skills[:-2] if skills is not "" else skills,
					# 	"job_type": data["type_of_job"],
					# 	"how_soon_required": data["how_soon_required"],
					# 	"industry": data["industries_id"]["name"] if data["industries_id"] else "",
					# 	"vacancy": 2,
					# 	"timing": timing,
					# 	"is_questionnaire": True if data["job_id_post_questionnaire"] else False,
					# 	"questionnaire_id": data["job_id_post_questionnaire"] if data[
					# 		"job_id_post_questionnaire"] else "",
					# 	"key": data["id"]
					# },
					"job_details":{
						"title": data["job_title"],
						"job_role": {"key": data["job_role"]["id"], "value": data["job_role"][
							"name"]} if data["job_role"] else {},
						"job_description": data["job_description"],
						"work_experience_min": data["min_experience"],
						"work_experience_max": data["max_experience"],
						"is_fresher": data["is_fresher"],
						"currency": {"key": data["currency"]["id"], "value": data["currency"][
							"name"]} if data["currency"] else {},
						"minimum_ctc": "Not Disclosed" if data["is_salary_visible"] else data["min_salary"],
						"maximum_ctc": "Not Disclosed" if data["is_salary_visible"] else data["max_salary"],
						"visible_to_no_one": data["is_salary_visible"],
						"number_of_vacancy": data["no_of_vacancies"],
						"how_soon": data["how_soon_required"],
						"industry": {"key": data["industries_id"]["id"], "value": data[
							"industries_id"]["name"]} if data["industries_id"] else {},
						"functional_area": {"key": data["functional_area_id"]["id"], "value": data["functional_area_id"]["name"]}  if data["functional_area_id"] else {},
						"job_type": data["type_of_job"],
						"status": data["status"],
						"count": data["from_count"],
						"locations": location_object,
						"timings": working_objects,
						"key_skills": skill_objects
					},
					# "candidate_profile": {
					# 	"back_to_work": data["is_longtime_break"],
					# 	"majors": major_names[:-2] if major_names != "" else "",
					# 	"specialisations": specialisation_names[:-2] if specialisation_names != "" else "",
					# 	"phd_majors": phd_majors_names[:-2] if phd_majors_names != "" else "",
					# 	"phd_specialisations": phd_specialisation_names[:-2] if phd_specialisation_names != "" else "",
					# 	"candidate_profile": data["candidate_profile"],
					# },
					"candidate_profile": {
						"back_to_work": data["is_longtime_break"],
						"job_is_for_organisation": is_show,
						"qualification": major_object,
						"specialisations": spec_object,
						"qualification_premier": data["is_graduate_premium_university"],
						"phd_qualification": phd_major_object,
						"phd_specialisations": phd_spec_object,
						"qualification_phd_premier": data["is_phd_premium_university"],
						"desired_candidate": data["candidate_profile"],
						"organisation_name": org_object
					},
					"manage_response": {
						"email_or_walkin": "email" if data["is_email_response"] else "walkin",
						"forward_application_to_email": data["is_email_forward"],
						"selected_email": data["forward_email_id"],
						"questioner_id": questionnaire_object,
						"reference_code": data["reference_code"],
						"date_from": data["job_id_walkin"][0]["start_date"] if data["job_id_walkin"] else "",
						"date_to": data["job_id_walkin"][0]["end_date"] if data["job_id_walkin"] else "",
						"time_from": data["job_id_walkin"][0]["start_time"] if data["job_id_walkin"] else "",
						"time_to": data["job_id_walkin"][0]["end_time"] if data["job_id_walkin"] else "",
						"venue": data["job_id_walkin"][0]["venue"] if data["job_id_walkin"] else "",
						"address_url": data["job_id_walkin"][0]["location_url"] if data["job_id_walkin"] else ""
					},
					"advertise_company_details":{"key":advertise_key},
					"publish_job": {"refresh_time": data["schedule_time"], "job_type":data["status"]},
					"get_in_touch": {
						"response_on": "Walkin" if not data["is_email_response"] else "Email",
						"reference_code": data["reference_code"]
					},
					"job_description_documents": {}
				}
				for values in data["job_id_walkin"]:
					response_data["get_in_touch"] = {
						"walkin_date": values["start_date"] + " - " + values["end_date"],
						"walkin_time": values["start_time"] + " - " + values["end_time"],
						"venue_get_in": values["venue"],
						"response_on": "Walkin" if not data["is_email_response"] else "Email",
						"reference_code": data["reference_code"]
					}
				for values in data["post_jobs_advertise_id"]:
					response_data["about_organisation"] = {
						"description": values["advertise_company_details_id"]["organisation_description"],
						"website": values["advertise_company_details_id"]["website_url"],
						"address": values["advertise_company_details_id"]["address"],
						"file_url": values["advertise_company_details_id"]["file_path"],
						"organisation_name": values["advertise_company_details_id"]["organisation_name"]["name"],
					}
				description_documents = JobDescriptionDocuments.objects.filter(job_id__id=id)
				print(len(description_documents))
				response_data['job_description_documents']["video"] =  postjob_queryset[0].video_description.url if postjob_queryset[0].video_description else ""
				if len(description_documents) != 0 and description_documents:
					response_data['job_description_documents'] = {
						"video": postjob_queryset[0].video_description.url if postjob_queryset[0].video_description else "",
						"video_updated_on": postjob_queryset[0].video_updated_on,
						"document_1": description_documents[0].document_1.url if description_documents[0] and description_documents[0].document_1 else "" ,
						"document_1_updated_on": description_documents[0].document_1_updated_on if description_documents[0].document_1_updated_on else "",
						"document_2": description_documents[0].document_2.url if description_documents[0] and description_documents[0].document_2 else "",
						"document_2_updated_on": description_documents[0].document_2_updated_on if description_documents[0].document_2_updated_on else "",
						"document_3": description_documents[0].document_3.url if description_documents[0] and description_documents[0].document_3 else "",
						"document_3_updated_on": description_documents[0].document_3_updated_on if description_documents[0].document_3_updated_on else "",
						"document_4": description_documents[0].document_4.url if description_documents[0] and description_documents[0].document_4 else "",
						"document_4_updated_on": description_documents[0].document_4_updated_on if description_documents[0].document_4_updated_on else "",
						"document_5": description_documents[0].document_5.url if description_documents[0] and description_documents[0].document_4 else "",
						"document_5_updated_on": description_documents[0].document_5_updated_on if description_documents[0].document_5_updated_on else ""
					}
				response_data['job_description_documents']["video"] = response_data['job_description_documents']["video"].split("pinkjob/media/")[1].replace("%3A",":/") if response_data['job_description_documents']["video"].__contains__("shenzyn.com") else response_data['job_description_documents']["video"]
			return Response(
				{"status": True, "message": Message["JOB_LISTING"]["PREVIEW_SUCCESS"], "application_status": stat, "data": response_data},
				status=200)
		except Exception as e:
			return Response({"status": False, "message": format(e)}, status=200)


# This is save jobs function when user click on save job that then we aill assign job id to user id in saved jobs table
class SaveJobs(APIView):
	@permission_required()
	def post(self, request):
		try:
			user_id, user_type = request.META["user_id"], request.META["user_type"]
			if 'id' not in request.data:
				return Response({"status": False, "message": Message["JOB_LISTING"]["SAVE_JOB_ERROR"]}, status=200)
			id = request.data["id"]
			if SavedJobs.objects.filter(job_id=id, user_id=user_id):
				return Response({"status": True, "message": Message["JOB_LISTING"]["SAVE_JOB_SUCCESS"]}, status=200)
			else:
				SavedJobs.objects.create(**{"job_id_id": id, "user_id_id": user_id})
				return Response({"status": True, "message": Message["JOB_LISTING"]["SAVE_JOB_SUCCESS"]}, status=200)
		except Exception as e:
			return Response({"status": True, "message": format(e)}, status=200)


class GetSavedJobs(APIView):
	# This response data function create result response depending on data fetch from database filter by given ids
	def response_data(self, ids):
		response_ = []
		postjob_queryset = PostJobs.objects.filter(id__in=ids).order_by("-created_on")
		serialiser_searchjobs = SearchJobsSerializer(postjob_queryset, many=True).data
		for values in serialiser_searchjobs:
			location, skills = "", ""
			for data in values["job_id_location"]:
				location += str(data["city_id"]["city"]) + ", "
			for data in values["job_id_skill"]:
				skills += str(data["qualities"]["value"]) + ", "
			skills = skills[:-2] if skills is not "" else skills
			location = location[:-2] if location is not "" else location
			print(values["created_on"])
			response_format = {
				"job_title": values["job_title"],
				"job_Role": values["job_role"]["name"] if values["job_role"] else "",
				"company_name":
					values["post_jobs_advertise_id"][0]["advertise_company_details_id"]["organisation_name"]["name"] if
					values["post_jobs_advertise_id"] else "",
				"experience_details": str(values["min_experience"]) + " - " + str(values["max_experience"]),
				"location": location,
				"expected_salary": str(values["min_salary"]) + " - " + str(values["max_salary"]) if values[
					"is_salary_visible"] is False else "Not Disclosed",
				"job_description": values["job_description"],
				"skills": skills,
				"posted_by": "Posted by " + self.get_posted_by_names(
					values["user_account_id"]["id"]) + " on " + datetime.datetime.strptime(values["created_on"],
					'%Y-%m-%dT%H:%M:%S.%fZ').strftime(
					"%d %b %Y"),
				"is_questionnaire": True if values["job_id_post_questionnaire"] else False,
				"questionnaire_id": values["job_id_post_questionnaire"] if values["job_id_post_questionnaire"] else "",
				"key": values["id"]
			}
			response_.append(response_format)
		return {"result": response_}

	# This function used to send selected limit result
	# If user select only show 5 result then this function send only 5 result by every page
	def sort_result_as_per_limit(self, ids, result_per_page, pagination):
		ids = ids[((result_per_page * pagination) - result_per_page):(result_per_page * pagination)]
		return ids

	# This function used to get about employer deatils for posted by filed
	def get_posted_by_names(self, id):
		employer_queryset = EmployerProfile.objects.filter(user_account_id=id)
		serialiser_data = PostedBySerializer(employer_queryset, many=True).data
		name = ""
		if serialiser_data:
			for data in serialiser_data[0]["employer_profile_id_about"]:
				name = data["about_employer"]
		return name

	# This function used to count result and send it to frontend for showing total result
	def result_count(self, result, result_per_page):
		array_data = {"total_result": len(result), "total_pagination": math.ceil(len(result) / int(result_per_page))}
		return array_data

	# this is get function of api which will return saved jobs list to user
	# Firstly we will find all saved job ids save assign to user profile then we will find related data
	@permission_required()
	def get(self, request):
		try:
			if "pagination" and "result_per_page" not in request.GET:
				return Response({"status": False, "message": Message["JOB_LISTING"]["GET_SAVE_JOB_ERROR"]}, status=200)
			user_id, user_type = request.META["user_id"], request.META["user_type"]
			ids, query_result = [], []
			saved_jobs_queryset = SavedJobs.objects.filter(user_id=user_id).order_by("-id")
			saved_jobs_serialiser = GetSavedJobsSerialiser(saved_jobs_queryset, many=True).data
			for values in saved_jobs_serialiser:
				query_result.append([values["job_id"]["id"], values["job_id"]["created_on"]])
				ids.append(values["job_id"]["id"])
			print(int(request.GET["result_per_page"]), int(request.GET["pagination"]))
			ids = self.sort_result_as_per_limit(ids, int(request.GET["result_per_page"]),
												int(request.GET["pagination"]))
			result = self.response_data(ids)
			result["counts"] = self.result_count(query_result, request.GET["result_per_page"])
			return Response({"status": True, "message": Message["JOB_LISTING"]["GET_SAVE_JOB_SUCCESS"], "data": result},
							status=200)
		except Exception as e:
			return Response({"status": False, "message": format(e)}, status=200)


class GetAppliedJobs(APIView):
	@permission_required()
	def get(self, request):
		try:
			return Response({"status": True, "message": Message["JOB_LISTING"]["SAVE_JOB_SUCCESS"]}, status=200)
		except Exception as e:
			return Response({"status": True, "message": format(e)}, status=200)


class SearchText(APIView):
	def remove_deuplicate(self, array):
		result = ""
		data = array.split(", ")
		data = list(set(data))
		for dat in data:
			result += dat + ", "
		return result if result == "" else result[:-2]

	def get(self, request):
		try:
			result = []
			post_jobs_queryset = raw_query_execute_function(
				"select employer_postjobs.id , employer_postjobs.job_title, employer_postjobs.job_description, employer_postjobs.min_experience, employer_postjobs.max_experience, employer_postjobs.min_salary, employer_postjobs.max_salary, employer_postjobs.how_soon_required, employer_postjobs.type_of_job, tx.website_url, tx.name, tx.organisation_description, sk.skill_set_name, lc.city, pm.phd_major, nm.major, ps.phd_spec, ns.spec from employer_postjobs left join (select employer_advertisecompanydetails.organisation_description, employer_advertisecompanydetails.website_url, employer_advertisecompanydetailsjobmapping.job_id_id, employer_organizations.name from employer_advertisecompanydetails, employer_advertisecompanydetailsjobmapping, employer_organizations where employer_advertisecompanydetails.id = employer_advertisecompanydetailsjobmapping.advertise_company_details_id_id and employer_organizations.id = employer_advertisecompanydetails.organisation_name_id ) as tx on tx.job_id_id=employer_postjobs.id left join (select job_seeker_skillset.skill_set_name, employer_desirecandidateprofileskills.job_id_id from job_seeker_skillset, employer_desirecandidateprofileskills where employer_desirecandidateprofileskills.qualities_id = job_seeker_skillset.id) as sk on sk.job_id_id=employer_postjobs.id left join (select job_seeker_location.city, employer_joblocations.job_id_id from employer_joblocations, job_seeker_location where employer_joblocations.city_id_id = job_seeker_location.id) as lc on lc.job_id_id=employer_postjobs.id left join (select distinct job_seeker_majors.major_name as phd_major, employer_jobrequiredphdqualifications.job_id_id from  job_seeker_majors, employer_jobrequiredphdqualifications where employer_jobrequiredphdqualifications.phd_major_id_id = job_seeker_majors.id) as pm on pm.job_id_id = employer_postjobs.id left join (select distinct job_seeker_majors.major_name as major, employer_jobrequiredqualifications.job_id_id from  job_seeker_majors, employer_jobrequiredqualifications where  employer_jobrequiredqualifications.major_id_id = job_seeker_majors.id) as nm on nm.job_id_id = employer_postjobs.id left join (select distinct job_seeker_specializations.specialization_name as phd_spec, employer_jobrequiredphdqualifications.job_id_id from  job_seeker_specializations, employer_jobrequiredphdqualifications where employer_jobrequiredphdqualifications.phd_specialization_id_id = job_seeker_specializations.id) as ps on ps.job_id_id = employer_postjobs.id left join (select distinct job_seeker_specializations.specialization_name as spec, employer_jobrequiredqualifications.job_id_id from  job_seeker_specializations, employer_jobrequiredqualifications where  employer_jobrequiredqualifications.specialization_id_id = job_seeker_specializations.id) as ns on ns.job_id_id = employer_postjobs.id;")
			for values in post_jobs_queryset:
				string, flag = "", False
				string += values[1] + ", " if values[1] != None and values[1] != "" else ""
				string += values[2] + ", " if values[2] != None and values[2] != "" else ""
				string += str(values[3]) + ", " if values[3] != None and values[3] != "" else ""
				string += str(values[4]) + ", " if values[4] != None and values[4] != "" else ""
				string += str(values[5]) + ", " if values[5] != None and values[5] != "" else ""
				string += str(values[6]) + ", " if values[6] != None and values[6] != "" else ""
				string += values[7] + ", " if values[7] != None and values[7] != "" else ""
				string += values[8] + ", " if values[8] != None and values[8] != "" else ""
				string += values[9] + ", " if values[9] != None and values[9] != "" else ""
				string += values[10] + ", " if values[10] != None and values[10] != "" else ""
				string += values[11] + ", " if values[11] != None and values[11] != "" else ""
				string += values[12] + ", " if values[12] != None and values[12] != "" else ""
				string += values[13] + ", " if values[13] != None and values[13] != "" else ""
				string += values[14] + ", " if values[14] != None and values[14] != "" else ""
				string += values[15] + ", " if values[15] != None and values[15] != "" else ""
				string += values[16] + ", " if values[16] != None and values[16] != "" else ""
				string += values[17] + ", " if values[17] != None and values[17] != "" else ""
				for data in result:
					if data["job_id"] == values[0]:
						data["string"] += ", " + string[:-2]
						flag = True
				if not flag:
					result.append({"job_id": values[0], "string": string[:-2]})
			for values in result:
				values["string"] = self.remove_deuplicate(values["string"])
			return Response({"status": True, "message": result, "data": ""}, status=200)
		except Exception as e:
			return Response({"status": True, "message": format(e)}, status=200)


# class SearchText(APIView):
#     def get(self, request):
#         from .elastic_search import create_string_in_elastic_search
#         return Response({"status":True,"data":create_string_in_elastic_search(request.GET["id"])}, status=200)


# This API will fetch the related questionnaire associated with the job id
class GetQuestionnaire(APIView):
	@permission_required()
	def post(self, request):
		# user_id, user_type = 1, 2
		status, message, data, name = False, "", [], ""
		try:
			user_id, user_type = request.META["user_id"], request.META["user_type"]
			req = request.data
			if (req == []) or (not all(key in req for key in ['job_id'])):
				message = "Invalid Request"
			else:
				job = req['job_id']
				if job == "":
					message = "Invalid Parameters"
				else:
					applied_status = JobApplications.objects.filter(Q(job_id__id=job) & Q(user_account_id__id=user_id))
					print(applied_status)
					questionnaire_query = JobPostQuestionnaire.objects.filter(job_id__id=job)
					print(questionnaire_query)
					if len(questionnaire_query) == 0:
						message = "No questionnaire exists for this job"
					else:
						print(questionnaire_query[0].questionnaire_id)
						name = questionnaire_query[0].questionnaire_id.questionnaire_name
						questionnaire = questionnaire_query[0].questionnaire_id.id
						questions_query = QuestionnaireQuestions.objects.filter(questionnaire_id__id=questionnaire)
						if len(questions_query) != 0:
							questions = [q.question_id.id for q in questions_query]
							for question in questions:
								q = questions_query.filter(question_id__id=question)[0]
								q_info = {
									"key": q.question_id.id,
									"value": q.question_id.question_text,
									"is_mandatory": q.question_id.is_mandatory,
									"options": []
								}
								options_query = QuestionOptionsMapping.objects.filter(question_id__id=question)
								for option in options_query:
									chunk = {
										"type": {
											"key": option.input_type_id.id,
											"value": option.input_type_id.input_type
										},
										"value": {
											"key": option.option_values_id.id,
											"value": option.option_values_id.option_name,
										}
									}
									q_info['options'].append(chunk)
								data.append(q_info)
							status, message = True, "Success"
		except Exception as e:
			traceback.print_exc()
			message = format(e)
		finally:
			return Response({"status": status, "message": message, "name": name, "data": data}, status=200)


# This API will save all the responses filled by the applicant for the job
class QuickApplyJobs(APIView):
	@permission_required()
	def post(self, request):
		# user_id, user_type = 1, 2
		status, message = False, ""
		try:
			# def SavedQuestionnaireResponses():
			# 	pass
			user_id, user_type = request.META["user_id"], request.META["user_type"]
			req = request.data
			if (req == []) or (not all(key in req for key in ['responses', 'job_id'])):
				message = "Invalid Request"
			else:
				responses, job_id = req['responses'], req['job_id']
				if job_id == "":
					message = "Please provide a job id"
				else:
					application_stat = JobApplications.objects.filter(Q(job_id__id=job_id) & Q(
						user_account_id__id=user_id))
					# print(len(application_stat), application_stat[0].id)
					if len(application_stat) != 0:
						message = "You have already applied for this job!"
					else:
						check = True
						save_questionnaire = False
						job_questionnaire_query = JobPostQuestionnaire.objects.filter(job_id__id=job_id)
						if len(job_questionnaire_query) != 0:
							if len(responses) == 0:
								message = "Please fill the questionnaire to successfully apply"
								check = False
							else:
								response_list = []
								for response in responses:
									b = [a for a in response]
									print(b)
									new_response = {
										# "application_id__id": application_stat[0].id,
										"question_id_id": response['question_id'],
										"answer": response['answer']
									}
									response_list.append(new_response)
								if len(response_list) != len(responses):
									message = "All responses could not be saved, changes rolled back!"
									check = False
									del response_list[:]
								else:
									save_questionnaire = True
									
						if check:
							quick_application_query = JobApplications.objects.create(**{
								"job_id_id": job_id, 
								"user_account_id_id": user_id,
								"job_application_status_id_id": 1, 
								"application_date": datetime.datetime.now()
							})
							JobApplicationStatus.objects.create(**{
								"job_application_id_id": quick_application_query.id,
								"job_application_status_id_id": 1,
								"action_date": datetime.datetime.now()})
							# Fetching the ID of job poster
							poster = quick_application_query.job_id.user_account_id.id
							# Checking if the poster's socket is present or not
							if poster in consumer_list:
								if len(consumer_list[poster]) != 0:
									# Sending to every sockets of the poster
									for socket in consumer_list[poster]:
										# Informing to increase the count by 1
										socket.websocket_send({"job_id": job_id, "applied_count": 1})
							if save_questionnaire:
								response_save_list = []
								for i in response_list:
									i["application_id_id"] = quick_application_query.id
									response_save_list.append(SavedQuestionnaireResponse(**i))
								SavedQuestionnaireResponse.objects.bulk_create(response_save_list)
							status, message = True, "Success"
		except Exception as e:
			traceback.print_exc()
			message = format(e)
		finally:
			return Response({"status": status, "message": message}, status=200)


# This function used to excecute raw query in database
# So we have just send query and it will return probable result
def raw_query_execute_function(query):
	cursor = connection.cursor()
	cursor.execute(query)
	return cursor.fetchall()
