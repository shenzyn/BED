# This is model file used for creating tables in database.
# So followings functions are tables names and inside declarations are filed names in datbase.
from django_mysql.models import JSONField, Model, EnumField
from employer.models import *
from employer.employer_homepage.homepage_models import Industries, FunctionalAreas ,Organizations
from employer.post_jobs.post_jobs_models import PostJobs


# following all are a database table names and there filed with datatype
class JobSeeker(models.Model):
    name = models.CharField(max_length=255)
    email = models.EmailField(max_length=255)
    mobile_number = models.BigIntegerField()
    created_on = models.DateTimeField(auto_now_add=True)


class OTPVerification(models.Model):
    verification_type=models.TextField()
    verification_id=models.CharField(max_length=320)
    otp = models.IntegerField()
    otp_status =models.CharField(max_length=1)
    timestamp = models.CharField(max_length=13)


class EducationalQualifications(models.Model):
    qualification_name = models.CharField(max_length=255, blank=True)


class Majors(models.Model):
    major_name = models.TextField(blank=True)
    qualification_id = models.ForeignKey(EducationalQualifications, related_name='majors', on_delete=models.CASCADE)


class Specializations(models.Model):
    specialization_name = models.TextField(blank=True)
    majors_id = models.ForeignKey(Majors, related_name='majors', on_delete=models.CASCADE)


class Universities(models.Model):
    university_name = models.TextField(blank=True)


class Institutes(models.Model):
    institute_name = models.TextField(blank=True)


class UniversitiesInstitutesMapping(models.Model):
    university_id = models.ForeignKey(Universities, related_name='university', on_delete=models.CASCADE)
    institute_id = models.ForeignKey(Institutes, related_name='institute', on_delete=models.CASCADE)


class Boards(models.Model):
    board_name = models.TextField(blank=True)


class Medium(models.Model):
    medium_name = models.TextField(blank=True)


class Designation(models.Model):
    name = models.CharField(max_length=255)
    is_default = models.BooleanField(default=0)


class CompanyNames(models.Model):
    company_name = models.TextField(blank=True)


class Location(models.Model):
    country = models.CharField(max_length=200)
    state = models.CharField(max_length=200)
    city = models.CharField(max_length=200)


class GradingSystem(models.Model):
    grading_system_name = models.CharField(max_length=50,null=True)


class DesiredCandidateProfile(models.Model):
    user_account_id = models.ForeignKey(UserAccount, related_name='user_account_desired_profile_id',
                                        on_delete=models.CASCADE)
    industry = models.ForeignKey(Industries, related_name='industry_desired_profile_id', on_delete=models.CASCADE)
    functional_area = models.ForeignKey(FunctionalAreas, related_name='functional_areas_desired_profile_id',
                                        on_delete=models.CASCADE)
    job_title = models.ForeignKey(Designation, related_name='title_desired_profile_id', on_delete=models.CASCADE)
    job_type = EnumField(choices=[
        "Part Time", "Full Time", "Full Time from Home", "Part Time from Home", "Freelancer"], null=True)
    desired_shift = EnumField(choices=["Day", "Night", "Flexible"], null=True)
    shift_time = models.CharField(max_length=30, null=True)
    availability = EnumField(choices=["Immediate", "Later"])
    availability_month = models.IntegerField(null=True)
    availability_year = models.IntegerField(null=True)
    expected_salary_currency = models.CharField(max_length=30, null=True)
    expected_salary_in_lacs = models.FloatField()

class PermenentResidency(models.Model):
    country = models.ForeignKey(Location, related_name='permenent_residency_location', on_delete=models.CASCADE,null=True)
    user_account_id = models.ForeignKey(UserAccount, related_name='user_account_permenent_residency_id',
                                        on_delete=models.CASCADE)

class DesiredProfileLocationMapping(models.Model):
    desired_profile_id = models.ForeignKey(DesiredCandidateProfile, related_name='desired_profile_location_id', on_delete=models.CASCADE,null=True)
    location = models.ForeignKey(Location, related_name='desired_profile_location', on_delete=models.CASCADE,null=True)


class SeekerProfile(Model):
    user_account_id = models.OneToOneField(UserAccount, related_name='user_account_seeker_id', on_delete=models.CASCADE)
    is_fresher = models.BooleanField(default=0)
    resume_document1 = models.FileField(upload_to='documents/resume/%Y/%m/%D/',null=True,blank=True)
    resume_video1 = models.FileField(upload_to='video/resume/%Y/%m/%D/',null=True,blank=True)
    resume_document2 = models.FileField(upload_to='documents/resume/%Y/%m/%D/',null=True,blank=True)
    resume_video2 = models.FileField(upload_to='video/resume/%Y/%m/%D/',null=True,blank=True)
    notice_period = models.CharField(max_length=20,null=True)
    break_reason = models.CharField(max_length=50,null=True)
    break_duration = models.CharField(max_length=50,null=True)
    marital_status = models.BooleanField(null=True)
    differently_abled = models.BooleanField(null=True)
    resume_headline = models.CharField(max_length=300,null=True)
    passport_number = models.CharField(max_length=45,null=True)
    category = models.CharField(max_length=45,null=True)
    # aadhar_url = models.FileField(upload_to='documents/%Y/%m/%D/',null=True,blank=True)
    hometown = models.ForeignKey(Location, related_name='id_city', on_delete=models.CASCADE, null=True)
    experience_in_years = models.IntegerField(null=True)
    experience_in_months = models.IntegerField(null=True)
    profile_summary = models.CharField(max_length=1000, null=True)
    aadhar_path = models.ImageField(upload_to='aadhar/%Y/%m/%D/', null=True, blank=True)
    

class AadharCardDeatils(models.Model):
    path = models.FileField(upload_to='aadhar/%Y/%m/%D/', null=True, blank=True)


class ExperienceDetails(models.Model):
    user_account_id = models.ForeignKey(UserAccount, related_name='user_account_exp_id', on_delete=models.CASCADE)
    is_current_job = models.BooleanField(default=0)
    start_date = models.DateField(null=True)
    end_date = models.DateField(null=True)
    job_title = models.ForeignKey(Designation, related_name='experience_id_designation', on_delete=models.CASCADE,null=True)
    company_name = models.ForeignKey(Organizations, related_name='experience_id_companies', on_delete=models.CASCADE,null=True)
    city = models.ForeignKey(Location, related_name='experience_id_city', on_delete=models.CASCADE,null=True)
    state = models.ForeignKey(Location, related_name='experience_id_state', on_delete=models.CASCADE,null=True)
    country = models.ForeignKey(Location, related_name='id_country', on_delete=models.CASCADE,null=True)
    organization_type = EnumField(choices=["Service Based", "Product Based", "Hybrid", "Startup"],default = "Service Based")
    notice_period = models.CharField(max_length=40, null=True)
    last_working_day = models.DateField(null=True)
    offered_job_title = models.ForeignKey(Designation, related_name='offered_designation', on_delete=models.CASCADE, null=True)
    offered_company_name = models.ForeignKey(CompanyNames, related_name='offered_companies', on_delete=models.CASCADE,null=True)
    is_buy_out_option = models.BooleanField(null=True)
    is_notice_negotiable = models.BooleanField(null=True)
    description = models.TextField(null=True)
    currency = models.CharField(max_length=30, null=True)
    annual_salary = models.FloatField(null=True)


class EducationalDetails(models.Model):
    user_account_id = models.ForeignKey(UserAccount, related_name='user_account_edu_id', on_delete=models.CASCADE)
    degree_name = models.ForeignKey(EducationalQualifications, related_name='degree', on_delete=models.CASCADE,null=True)
    major = models.ForeignKey(Majors, related_name='major', on_delete=models.CASCADE,null=True)
    specialization = models.ForeignKey(Specializations, related_name='specialization', on_delete=models.CASCADE,null=True)
    university = models.ForeignKey(Universities, related_name='universities', on_delete=models.CASCADE,null=True)
    institute = models.ForeignKey(Institutes, related_name='insitute', on_delete=models.CASCADE,null=True)
    start_date = models.DateTimeField(null=True)
    completion_date = models.DateTimeField(null=True)
    grading_system = models.ForeignKey(GradingSystem, related_name='grading_system_edu_id', on_delete=models.CASCADE,null=True)
    percentage = models.DecimalField(max_digits=5, decimal_places=2, blank=True, null=True)
    board = models.ForeignKey(Boards, related_name='board', on_delete=models.CASCADE,null=True)
    medium = models.ForeignKey(Medium, related_name='mediums', on_delete=models.CASCADE,null=True)
    passed_out_year = models.CharField(max_length=10,null=True)


class SkillSet(models.Model):
    skill_set_name = models.CharField(max_length=50,null=True)


class SeekerSkillSet(models.Model):
    user_account_id = models.ForeignKey(UserAccount, related_name='user_account_skill_id', on_delete=models.CASCADE)
    skill_set_id = models.ForeignKey(SkillSet, related_name='skill_set_name_id', on_delete=models.CASCADE)


class ProjectDetails(models.Model):
    user_account_id = models.ForeignKey(UserAccount, related_name='user_project_detail_id', on_delete=models.CASCADE)
    project_title = models.CharField(max_length=45, null=True)
    job_title = models.ForeignKey(Designation, related_name='job_title_projects', on_delete=models.CASCADE)
    qualifications = models.ForeignKey(EducationalQualifications, related_name='project_qualifications_id', on_delete=models.CASCADE)
    specializations = models.ForeignKey(Specializations, related_name='project_specialization', on_delete=models.CASCADE)
    organization = models.ForeignKey(Organizations, related_name='project_organization', on_delete=models.CASCADE)
    status = models.BooleanField(null=True)
    start_date = models.DateField(null=True)
    end_date = models.DateField(null=True)
    project_location = models.TextField(null=True)
    project_description = models.CharField(max_length=300, null=True)
    project_site = EnumField(choices=["Offsite", "Onsite"], null=True)
    project_nature = EnumField(choices=["Full Time", "Part Time", "Trainee"], null=True)
    team_size = models.IntegerField()
    team_role = models.ForeignKey(Designation, related_name='team_role_projects', on_delete=models.CASCADE,null=True)
    role_description = models.CharField(max_length=250, null=True)
    document = models.FileField(upload_to='documents/project_details/%Y/%m/%D/',null=True,blank=True)


class InternshipDetails(models.Model):
    user_account_id = models.ForeignKey(UserAccount, related_name='internship_user', on_delete=models.CASCADE)
    job_title = models.ForeignKey(Designation, related_name='job_title_internships', on_delete=models.CASCADE)
    company_name = models.ForeignKey(Organizations, related_name="company_name_internship", on_delete=models.CASCADE)
    tenure_in_years = models.IntegerField(null=True)
    tenure_in_months = models.IntegerField(null=True)
    added_date = models.DateField(null=True)


class TrainingDetails(models.Model):
    user_account_id = models.ForeignKey(UserAccount, related_name='training_user', on_delete=models.CASCADE)
    course_name = models.CharField(max_length=45, null=True)
    institute_name = models.ForeignKey(Institutes, related_name='training_institute', on_delete=models.CASCADE)
    start_date = models.DateField(null=True)
    end_date = models.DateField(null=True)


class OnlineProfiles(models.Model):
    user_account_id = models.ForeignKey(UserAccount, related_name='online_profile_user', on_delete=models.CASCADE)
    profile_name = models.CharField(max_length=50, null=True)
    url = models.TextField(null=True)
    description = models.CharField(max_length=250, null=True)


class ProjectSkillSetMapping(models.Model):
    project_id = models.ForeignKey(ProjectDetails, related_name='project_skill_profile_id', on_delete=models.CASCADE)
    skill_set_id = models.ForeignKey(SkillSet, related_name='project_skill_skill_id', on_delete=models.CASCADE)


class Patents(models.Model):
    user_account_id = models.ForeignKey(UserAccount, related_name='patents_user', on_delete=models.CASCADE)
    title = models.CharField(max_length=50, null=True)
    url = models.TextField(null=True)
    patent_office = models.CharField(max_length=200, null=True)
    status = models.BooleanField(null=True)
    application_number = models.CharField(max_length=50, null=True)
    issue_date_in_years = models.IntegerField()
    issue_date_in_months = models.IntegerField()
    description = models.CharField(max_length=500, null=True)


class Presentations(models.Model):
    user_account_id = models.ForeignKey(UserAccount, related_name='presentations_user', on_delete=models.CASCADE)
    title = models.CharField(max_length=50, null=True)
    url = models.TextField(null=True)
    description = models.CharField(max_length=500, null=True)


class Certifications(models.Model):
    user_account_id = models.ForeignKey(UserAccount, related_name='certifications_user', on_delete=models.CASCADE)
    certificate_names = models.CharField(max_length=50, null=True)
    certificate_body = models.CharField(max_length=100, null=True)
    year = models.IntegerField()


class WorkSamples(models.Model):
    user_account_id = models.ForeignKey(UserAccount, related_name='work_sample_user', on_delete=models.CASCADE)
    work_title = models.CharField(max_length=50, null=True)
    url = models.TextField(null=True)
    description = models.CharField(max_length=500, null=True)
    currently_working = models.BooleanField(null=True)
    start_date = models.DateField(null=True)
    end_date = models.DateField(null=True)


class ResearchPapers(models.Model):
    user_account_id = models.ForeignKey(UserAccount, related_name='research_papaer_name', on_delete=models.CASCADE)
    title = models.CharField(max_length=50, null=True)
    url = models.TextField(null=True)
    description = models.CharField(max_length=500, null=True)
    start_date = models.DateField(null=True)
    end_date = models.DateField(null=True)
    is_currently_working = models.BooleanField(null=True)
    duration_in_years = models.IntegerField(null=True)
    duration_in_months = models.IntegerField(null=True)


class Technologies(models.Model):
    user_account_id = models.ForeignKey(UserAccount, related_name='technologies_user', on_delete=models.CASCADE)
    technology_name = models.CharField(max_length=50)
    experience_in_years = models.IntegerField(null=True)
    experience_in_months = models.IntegerField(null=True)


class Rewards(models.Model):
    user_account_id = models.ForeignKey(UserAccount, related_name='rewards_user', on_delete=models.CASCADE)
    title = models.CharField(max_length=50, null=True)
    description = models.CharField(max_length=500, null=True)


class Languages(models.Model):
    language_name = models.CharField(max_length=30)


class LanguageDetails(models.Model):
    user_account_id = models.ForeignKey(UserAccount, related_name='language_user', on_delete=models.CASCADE,null=True)
    language = models.ForeignKey(Languages, related_name='language_name_map', on_delete=models.CASCADE,null=True)
    read = models.BooleanField(null=True)
    write = models.BooleanField(null=True)
    speak = models.BooleanField(null=True)
