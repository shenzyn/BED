from django.urls import path,include
from .homepage_views import *
from employer.sub_user.views import HomepageStatus

urlpatterns = [
    path('know-about-employer/',KnowAboutEmployer.as_view()),
    path('send-otp/',SendAccountValidateOtp.as_view()),
    path('verify-otp-and-populate-details/',VerifyOTPAndPoputateDetails.as_view()),
    path('get-basic-profile-details/',GetBasicProfileDetails.as_view()),
    path('update-basic-profile-details/',UpdateBasicProfileDetails.as_view()),
    path('get-url-suggestions/',GetUrlSuggestions.as_view()),
    path('customise-url/',CustomiseUrl.as_view()),
    path('update-profile-headline/',ProfileHeadline.as_view()),
    path('get-profile-headline/',GetProfileHeadline.as_view()),
    path('get-industries/',GetIndustries.as_view()),
    path('get-organisations/',GetOrganisations.as_view()),
    path('get-functional-areas/',GetFunctionalAreas.as_view()),
    path('get-levels/',GetLevelIHire.as_view()),
    path('get-contact-details/',GetContactDetails.as_view()),
    path('update-contact-details/',UpdateContactDetails.as_view()),
    path('get-work-experience-details/',GetWorkExperienceDetails.as_view()),
    path('get-sector-roles/',HireForDetails.as_view()),
    path('update-sector-roles/',HireForDetails.as_view()),
    path('add-work-experience-details/',AddWorkExperienceDetails.as_view()),
    path('update-work-experience-details/',UpdateWorkExperienceDetails.as_view()),
    path('delete-work-experience-details/',DeleteWorkExperienceDetails.as_view()),
    path('upload-documents/',UploadDocuments.as_view()),
    path('get-documents/',GetDocuments.as_view()),
    path('delete-documents/',DeleteDocuments.as_view()),
    path('personal-info-email-otp/',ContactDetailsEmailOtp.as_view()),
    path('check-bussiness-email/',EmailVerification.as_view()),
    path('personal-info-phone-otp/',ContactDetailsPhoneOtp.as_view()),
    path('personal-info-email-otp-validate/', ContactDetailsEmailOtpValidate.as_view()),
    #path('login-detail-email-otp-validate/', LoginDetailsEmailOtpValidate.as_view()),
    path('personal-info-phone-otp-validate/',ContactDetailsPhoneOtpValidate.as_view()),
    path('homepage-status/', HomepageStatus.as_view())
]
