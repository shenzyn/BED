from employer.models import *
from job_seeker.models import *
from partial_date import PartialDateField
import time
from datetime import datetime


class Organizations(models.Model):
    name = models.CharField(max_length=255)
    is_default = models.BooleanField(default=0)


class Industries(models.Model):
    name = models.CharField(max_length=255)
    is_default = models.BooleanField(default=0)


class FunctionalAreas(models.Model):
    name = models.CharField(max_length=255)
    is_default = models.BooleanField(default=0)


class LevelIHire(models.Model):
    name = models.CharField(max_length=255)
    is_default = models.BooleanField(default=0)


class CompanyDetails(models.Model):
    pan = models.CharField(max_length=10, null=True)
    pan_file_path = models.FileField(upload_to='documents/company_details/%Y/%m/%D/', null=True, blank=True)
    gst_file_path = models.FileField(upload_to='documents/company_details/%Y/%m/%D/', null=True, blank=True)
    doc3_path = models.FileField(upload_to='documents/company_details/%Y/%m/%D/', null=True, blank=True)
    doc4_path = models.FileField(upload_to='documents/company_details/%Y/%m/%D/', null=True, blank=True)
    doc5_path = models.FileField(upload_to='documents/company_details/%Y/%m/%D/', null=True, blank=True)
    is_company_verified = models.BooleanField(default=0)


class EmployerProfile(models.Model):
    user_account_id = models.OneToOneField(UserAccount, related_name='user_account_id_profile', on_delete=models.CASCADE)
    designation_id = models.ForeignKey('job_seeker.Designation', related_name='designation_id', on_delete=models.CASCADE, null=True)
    organization_id = models.ForeignKey(Organizations, related_name='organizations_id', on_delete=models.CASCADE,null=True)
    facebook_url = models.CharField(max_length=255,null=True)
    linkedin_url = models.CharField(max_length=255,null=True)
    current_country = models.ForeignKey('job_seeker.Location', related_name='current_country_id', on_delete=models.CASCADE, null=True)
    current_city = models.ForeignKey('job_seeker.Location', related_name='current_city_id', on_delete=models.CASCADE, null=True)
    business_email = models.EmailField(max_length=329, null=True)
    is_business_email_verified = models.BooleanField(default=0)
    secondary_email = models.EmailField(max_length=329,null=True)
    profile_headline = models.CharField(max_length=300,null=True)
    customize_profile_url = models.CharField(max_length=30,null=True)
    about_employer = models.CharField(max_length=30,null=True)
    created_on = models.BigIntegerField(null=True)
    

class SubUserStatus(models.Model):
    employer_profile_id = models.ForeignKey(EmployerProfile, related_name='employer_profile_id_status', on_delete=models.CASCADE)
    parent_id = models.ForeignKey(UserAccount, related_name='parent_id', on_delete=models.CASCADE,null=True)
    permissions = models.TextField(null=True)
    is_admin = models.BooleanField(default=0)
    suspended_date = models.BigIntegerField(null=True)
    suspended_till = models.DateField(null=True)
    company_details_id = models.ForeignKey(CompanyDetails, related_name='company_details_id_id', on_delete=models.CASCADE, null=True)
    sub_user_status = models.CharField(max_length=30,null=True)
    sub_user_reason = models.CharField(max_length=500, null=True)
    updated_on = models.BigIntegerField(null=True)
    


class AboutEmployer(models.Model):
    about_employer = models.CharField(max_length=30,null=True)
    employer_id = models.ForeignKey(EmployerProfile, related_name='employer_profile_id_about', on_delete=models.CASCADE)


class EmployerWorkExperience(models.Model):
    user_account_id = models.ForeignKey(UserAccount, related_name='user_account_id_work_experience', on_delete=models.CASCADE)
    designation_id = models.ForeignKey('job_seeker.Designation', related_name='designation_id1', on_delete=models.CASCADE,null=True)
    organization_id = models.ForeignKey(Organizations, related_name='organizations_id1', on_delete=models.CASCADE,null=True)
    description = models.CharField(max_length=500,null=True)
    is_current_job = models.BooleanField(default=True)
    start_date = PartialDateField(null=True)
    end_date = PartialDateField(null=True)


class EmployerDocuments(models.Model):
    user_account_id = models.ForeignKey(UserAccount, related_name='user_account_id_documents', on_delete=models.CASCADE)
    document = models.FileField(upload_to='documents/employer_documents/%Y/%m/%D/',null=True,blank=True)
    document_name = models.CharField(max_length=50, null=True)


class DefaultPermissions(models.Model):
    permission_name = models.CharField(max_length=50, null=True)
    is_admin = models.BooleanField(default=True)


class EmployerHiringLevelsMapping(models.Model):
    level_i_hire_id = models.ForeignKey(LevelIHire, related_name='employer_level_i_hire_id', on_delete=models.CASCADE,null=True)
    user_account_id = models.ForeignKey(UserAccount, related_name='user_account_id_level_i_hire', on_delete=models.CASCADE)


class EmployerHiringOrganizationsMapping(models.Model):
    organiztion_id = models.ForeignKey(Organizations, related_name='employer_organization_id', on_delete=models.CASCADE,null=True)
    user_account_id = models.ForeignKey(UserAccount, related_name='organization_user_account_id', on_delete=models.CASCADE)


class EmployerHiringIndustriesMapping(models.Model):
    industries_id = models.ForeignKey(Industries, related_name='employer_industries_hire_id', on_delete=models.CASCADE,null=True)
    user_account_id = models.ForeignKey(UserAccount, related_name='industries_i_hire_user_account_id', on_delete=models.CASCADE)


class EmployerHiringFunctionalAreasMapping(models.Model):
    functional_areas_id = models.ForeignKey(FunctionalAreas, related_name='employer_functional_areas_id', on_delete=models.CASCADE,null=True)
    user_account_id = models.ForeignKey(UserAccount, related_name='user_account_id', on_delete=models.CASCADE)


class EmployerHiringSkillSet(models.Model):
    user_account_id = models.ForeignKey(UserAccount, related_name='employer_hiring_skill_set_id', on_delete=models.CASCADE)
    skill_set_id = models.ForeignKey('job_seeker.SkillSet', related_name='employer_hiring_skill_set_name_id', on_delete=models.CASCADE)
