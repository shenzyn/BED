from .homepage_models import *
from rest_framework import serializers


class EmployerWorkExperienceSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmployerWorkExperience
        fields = '__all__'

class EmployerProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmployerProfile
        fields = '__all__'


class OrganisationSerializer(serializers.ModelSerializer):
    value = serializers.CharField(source='name')
    key = serializers.IntegerField(source='id')

    class Meta:
        model = Organizations
        fields = ["key", "value"]


class IndustriesSerializer(serializers.ModelSerializer):
    value = serializers.CharField(source='name')
    key = serializers.IntegerField(source='id')

    class Meta:
        model = Industries
        fields = ('key', 'value')


class FunctionalAreasSerializer(serializers.ModelSerializer):
    value = serializers.CharField(source='name')
    key = serializers.IntegerField(source='id')

    class Meta:
        model = FunctionalAreas
        fields = ('key', 'value')


class LevelIHireSerializer(serializers.ModelSerializer):
    value = serializers.CharField(source='name')
    key = serializers.IntegerField(source='id')

    class Meta:
        model = LevelIHire
        fields = ('key', 'value')


# This serialiser used for only geting company document urls
class EmployerDocumentsSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmployerProfile
        fields = ["company_details_id"]
        depth = 2


# This serialiser used for only geting user_acount status details
class EmployerHomepageStatusSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmployerProfile
        fields = "__all__"
        depth = 2


# This seriliser used in get basic profile deatils
class EmployerBasicProfileDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmployerProfile
        fields = ("current_city", "current_country", "organization_id", "designation_id", "user_account_id")
        depth = 2


class OrganizationsSerializer(serializers.ModelSerializer):
    value = serializers.CharField(source='name')
    key = serializers.IntegerField(source='id')

    class Meta:
        model = Organizations
        fields = ('key', 'value')

class SkillSetSerializer(serializers.ModelSerializer):
    value = serializers.CharField(source='skill_set_name')
    key = serializers.IntegerField(source='id')

    class Meta:
        model = 'job_seeker.SkillSet'
        fields = ('key', 'value')


class DefaultPermissionsSerializer(serializers.ModelSerializer):
    class Meta:
        model = DefaultPermissions
        fields = ["permission_name"]

class IndustreisEmployerSerializer(serializers.ModelSerializer):
    industries_id = IndustriesSerializer()
    class Meta:
        model = EmployerHiringIndustriesMapping
        fields = ['industries_id']

class FunctionalAreasEmployerSerializer(serializers.ModelSerializer):
    functional_areas_id = FunctionalAreasSerializer()
    class Meta:
        model = EmployerHiringFunctionalAreasMapping
        fields = ['functional_areas_id']


class EmployerHiringSkillSetSerializer(serializers.ModelSerializer):
    skill_set_id = SkillSetSerializer()
    class Meta:
        model = EmployerHiringSkillSet
        fields = ['skill_set_id']


class EmployerHiringOrganizationsMappingSerializer(serializers.ModelSerializer):
    organiztion_id = OrganizationsSerializer()
    class Meta:
        model = EmployerHiringOrganizationsMapping
        fields = ['organiztion_id']

class EmployerHiringLevelsMappingSerializer(serializers.ModelSerializer):
    level_i_hire_id = LevelIHireSerializer()
    class Meta:
        model = EmployerHiringLevelsMapping
        fields = ["level_i_hire_id"]


class HireForSectionSerializer(serializers.ModelSerializer):
    indust = IndustreisEmployerSerializer(many=True)
    function_areas = FunctionalAreasEmployerSerializer(many=True)
    skill_sets = EmployerHiringSkillSetSerializer(many=True)
    organizations = EmployerHiringOrganizationsMappingSerializer(many=True)
    levels = EmployerHiringLevelsMappingSerializer(many=True)

    class Meta:
        model = UserAccount
        fields = ('id', 'indust', 'function_areas', 'skill_sets', 'organizations', 'levels')

class CompanyDetailsSerializer(serializers.ModelSerializer):

    class Meta:
        model = CompanyDetails
        fields = '__all__'