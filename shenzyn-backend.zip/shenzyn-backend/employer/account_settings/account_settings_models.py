from django.db import models
from django_mysql.models import EnumField
from employer.employer_homepage.homepage_models import FunctionalAreas, Industries, Organizations
from employer.models import UserAccount
from job_seeker.models import Designation, Location, Majors, Specializations


