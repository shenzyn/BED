from rest_framework.views import APIView
from rest_framework.response import Response
from employer.decorators import permission_required
from .account_settings_serializers import *
from django.db.models import Q
from django.db import connection
from pinkjob.utils import *
from employer.employer_homepage.homepage_models import *
from job_seeker.models import OTPVerification
from datetime import datetime, timedelta
from dateutil.relativedelta import *
from pinkjob.server_settings import *
from pinkjob import settings
from employer.serializers import EmployerSerializer
import time
import pdb




# This function will send the user's Email ID initially
class SendUserEmail(APIView):
	@permission_required()
	def get(self, request):
		status, message, data = False, "", {}
		try:
			user_id, user_type = request.META["user_id"], request.META["user_type"]
			query_set = EmployerProfile.objects.filter(user_account_id_id=user_id)
			serializer = GetEmailSerializer(query_set, many=True).data
			if len(serializer) == 1:
				status, message = True, "Success"
				data = {
					"email": serializer[0]["user_account_id"]["email_id"],
					"status": serializer[0]["user_account_id"]['employer_profile_status']
				}
			else:
				message = Message["ACCOUNT_SETTINGS"]["USER_COUNT_CONFLICT"]
		except Exception as e:
			message = format(e)
		finally:
			return Response({"status": status, "message": message, "data": data}, status=200)


# This function allows to edit user's Email ID
class ChangeUserEmail(APIView):
	@permission_required()
	def post(self, request):
		status, message = False, ""
		try:
			user_id, user_type = request.META["user_id"], request.META["user_type"]
			data = request.data
			if (data is []) or (not all(k in data for k in ("new_email", "password"))):
				message = Message["ACCOUNT_SETTINGS"]["INVALID_REQUEST"]
			else:
				new_email = data['new_email']
				pwd = data['password']
				validity = email_length_check(new_email)
				if validity['result']:
					query_set = UserAccount.objects.filter(Q(id=user_id) & Q(password=pwd))
					if len(query_set) == 1:
						existence = UserAccount.objects.filter(Q(email_id=new_email) & Q(is_employer=True)).exists()
						if existence:
							message = Message["EMAIL_IS_REGISTER_WITH_US"]
						else:
							query_set[0].email_id = new_email
							query_set[0].save()
							status, message = True, Message["ACCOUNT_SETTINGS"]["EMAIL_CHANGE_SUCCESS"]
					else:
						message = Message["ACCOUNT_SETTINGS"]["PASSWORD_INCORRECT"]
				else:
					message = validity['message']
		except Exception as e:
			message = format(e)
		finally:
			return Response({"status": status, "message": message}, status=200)


# This function allows to edit user's Password
class ChangeUserPassword(APIView):
	@permission_required()
	def post(self, request):
		status, message = False, ""
		try:
			user_id, user_type = request.META["user_id"], request.META["user_type"]
			data = request.data
			if (data is []) or (not all(key in data for key in ('old_pwd', 'new_pwd', 'conf_pwd'))):
				message = Message["ACCOUNT_SETTINGS"]["INVALID_REQUEST"]
			else:
				old_pwd, new_pwd, conf_pwd = data['old_pwd'], data['new_pwd'], data['conf_pwd']
				if old_pwd == "":
					message = Message["ACCOUNT_SETTINGS"]["EMPTY_CURRENT_PASSWORD"]
				elif new_pwd == "":
					message = Message["ACCOUNT_SETTINGS"]["EMPTY_NEW_PASSWORD"]
				elif conf_pwd == "":
					message = Message["ACCOUNT_SETTINGS"]["EMPTY_CONFIRM_PASSWORD"]
				elif new_pwd != conf_pwd:
					message = Message["ACCOUNT_SETTINGS"]["REENTERED_PASSWORD_MISMATCH"]
				elif old_pwd == new_pwd:
					message = Message["ACCOUNT_SETTINGS"]["PASSWORD_REUSE_ERROR"]
				elif is_password_valid(new_pwd):
					query_set = UserAccount.objects.filter(id=user_id)
					if len(query_set) != 1:
						message = Message["ACCOUNT_SETTINGS"]["USER_COUNT_CONFLICT"]
					else:
						if query_set[0].password != old_pwd:
							message = Message["ACCOUNT_SETTINGS"]["PASSWORD_INCORRECT"]
						else:
							query_set[0].password = new_pwd
							query_set[0].save()
							status, message = True, Message["ACCOUNT_SETTINGS"]["PASSWORD_CHANGE_SUCCESS"]
				else:
					message = Message["ACCOUNT_SETTINGS"]["PASSWORD_INVALID"]
		except Exception as e:
			message = format(e)
		finally:
			return Response({"status": status, "message": message}, status=200)


# settings.scheduler.remove_job(buyer_db_name+'-'+str(days) + str(contracts[0].id))
# settings.scheduler.add_job(alert_of_expiry_date, 'date', jobstore='redis', run_date=mydate,
# 	id=buyer_db_name+'-'+str(days) + str(contracts[0].id), args=
# 	[contracts[0].c_name, contracts[0].expiry_notification_email,
# 	days, buyer_db_name])
#
#
# def alert_of_expiry_date(contracts_name, email, days, buyer_db_name):
#     mails = {"mails": []}
#     for one_email in email:
#         if days == 0:
#             message = "Contract "+contracts_name+" is Expired"
#         else:
#             message = "Contract " + contracts_name + " will expire in "+str(days)+" days"
#         mails["mails"].append(
#             {"from": "support@selekt.in", "to": one_email, "subject": message, "html": message})
#     r = requests.post(settings.MAIL_URL, json=mails)
#Delete Shenzyn Account: Within 2 days
#
def send_mails(email_id,subject,body,user_id):
	print("coming")
	send_email(subject, body, "gupta@selekt.in", [email_id])
	print(subject == 'Shenzyn Account Deleted',subject,'Shenzyn Account Deleted')
	if subject == 'Shenzyn Account Deleted':
		print("coming inside subject")
		emp_query = UserAccount.objects.filter(id=user_id).update(employer_profile_status='complete_deleted')
		#print(emp_query,emp_query[0].employer_profile_status)

def update_status(user_id):
	emp_query = UserAccount.objects.filter(id=user_id)
	emp_query[0].employer_profile_status = "complete_deleted";
	emp_query[0].save()

def check_admin_status(employer_profile_id):
	employer_details_query = SubUserStatus.objects.filter(employer_profile_id_id=employer_profile_id,is_admin=1,sub_user_status="active")
	if employer_details_query:
		company_id = employer_details_query[0].company_details_id_id;
		if company_id:
			company_details_query = SubUserStatus.objects.filter(company_details_id_id=company_id,is_admin=1,sub_user_status="active") 
			print(company_details_query,len(company_details_query))
			if len(company_details_query) > 1:
				return True;
			else:
				return False;
		else:
			return False;
	return False;

# This function allows the user delete his/her own account
class AlterUserAccount(APIView):
	@permission_required()
	def post(self, request):
		status, message, act, reason, time_frame, user_id = False, "", "", "", "", ""
		try:
			user_id, user_type = request.META["user_id"], request.META["user_type"]
			data = request.data
			if (data is []) or (not all(k in data for k in ("action", "reason"))): #, "time_frame"
				message = Message["ACCOUNT_SETTINGS"]["INVALID_REQUEST"]
			else:
				action, reason, time_frame = data['action'], data['reason'], ""#data['time_frame']
				emp_query = EmployerProfile.objects.filter(user_account_id=user_id)
				email_id = emp_query[0].user_account_id.email_id;
				name = emp_query[0].user_account_id.first_name;
				print(email_id)
				if len(emp_query) == 1:
					emp_status = emp_query[0].user_account_id.employer_profile_status
					if emp_status != "deleted" or emp_status != "complete_deleted":
						if action == "suspend":
							if emp_status == "suspended":
								message = Message["ACCOUNT_SETTINGS"]["ACCOUNT_SUSPENDED_WARNING"]
							# elif time_frame == "":
							# 	message = Message["ACCOUNT_SETTINGS"]["TIME_FRAME_NOT_PROVIDED"]
							else:
								if check_admin_status(emp_query[0].id):
									act, status, message = "suspended", True, Message["ACCOUNT_SETTINGS"]["ACCOUNT_SUSPENSION_SUCCESS"]
								else:
									act, status, message = "active", False, Message["ACCOUNT_SETTINGS"]["ACCOUNT_NOT_SUSPENDING"]
						elif action == "delete":
							if check_admin_status(emp_query[0].id):
								curr_time = int(time.time()) * 1000
								emp_query[0].user_account_id.account_deleted_date = curr_time
								emp_query[0].save()
								date = datetime.now()
								date = date + relativedelta(minutes=+5)
								remainder_date = date - relativedelta(minutes=+2)
								subject = "Delete Shenzyn Account: "+str(date).split('.')[0];
								url=server_settings["base_url"]+"/employer-signup/"
								body = "Hi "+name+", <br/><br/>Your account has been deleted, but it can be restored anytime till 2 Months. After 2 months, it will get permanently deleted.<br/><br/>Regards,<br/>Shenzyn Team.";
								send_email(subject, body, "gupta@selekt.in", [email_id])
								settings.scheduler.add_job(send_mails, 'date', jobstore='redis', run_date=remainder_date,
														id=str(user_id) + '-' +'ac-remainder-mail', args=
														[email_id,"Delete Shenzyn Account: Within 2 days","Hi "+name+", <br/><br/>You have 2 days left, your account will be deleted after that <br/><br/>Kindly contact support@shenzyn.com for more information.<br/><br/>Regards,<br/>Shenzyn Team.",user_id])
								settings.scheduler.add_job(send_mails, 'date', jobstore='redis', run_date=date,
														id=str(user_id) + '-' + 'ac-delete-mail', args=
														[email_id, "Shenzyn Account Deleted",
															"Hi "+name+", <br/><br/>Your account has been deleted. You can make your new account from <a href='"+url+"'>here</a>. Do connect with us in the future. <br/><br/>Kindly contact support@shenzyn.com for more information.<br/><br/>Regards,<br/>Shenzyn Team.",user_id])

								settings.scheduler.add_job(update_status, 'date', jobstore='redis', run_date=date,id=str(user_id) + '-' + 'ac-delete-update-status',args=[user_id])
								act, status, message = "deleted", True, Message["ACCOUNT_SETTINGS"]["ACCOUNT_DELETION_SUCCESS"]
							else:
								act, status, message = "active", False, Message["ACCOUNT_SETTINGS"]["ACCOUNT_NOT_DELETING"]
						elif action == "activate":
							if emp_status == "active":
								message = Message["ACCOUNT_SETTINGS"]["ACCOUNT_ACTIVE_WARNING"]
							else:
								act, status, message = "active", True, Message["ACCOUNT_SETTINGS"]["ACCOUNT_ACTIVATION_SUCCESS"]
						else:
							message = Message["ACCOUNT_SETTINGS"]["INVALID_ACTION_REQUEST"]
					else:
						message = Message["ACCOUNT_SETTINGS"]["ACCOUNT_DELETED_WARNING"]
				else:
					message = Message["ACCOUNT_SETTINGS"]["USER_COUNT_CONFLICT"]
		except Exception as e:
			message = format(e)
		finally:
			print(act,'printing')
			if act != "":
				emp_status_query = UserAccount.objects.filter(id=user_id)
				print(len(emp_status_query), emp_status_query[0].employer_profile_status, act)
				emp_status_query[0].employer_profile_status = act
				emp_status_query[0].save()
				curr_time = int(time.time()) * 1000
				if act == "deleted":
					emp_status_query[0].account_reason = reason
					emp_status_query[0].account_deleted_date = curr_time
					emp_status_query[0].save()
			return Response({"status": status, "message": message}, status=200)


# This function returns the list of All Sub-Users as per the status requested
class GetSubUserList(APIView):
	@permission_required()
	def get(self, request):
		status, message, data, count = False, "", [], 0
		try:
			user_id, user_type = request.META["user_id"], request.META["user_type"]
			req = request.GET
			if (req is []) or (not all(k in req for k in ("status", "page", "limit"))):
				message = Message["ACCOUNT_SETTINGS"]["INVALID_REQUEST"]
			else:
				state, page, limit = req["status"], req["page"], req["limit"]
				query_set = EmployerProfile.objects.filter(Q(user_account_id=user_id) & Q(is_sub_user=False))
				if len(query_set) == 1:
					org_id = query_set[0].organization_id
					sub_user_list = EmployerProfile.objects.filter(Q(organization_id=org_id) & Q(is_sub_user=True) & Q(sub_user_status=state))
					serialized_list = ProfileSerializer(sub_user_list, many=True).data
					status, message, data, count = True, Message["ACCOUNT_SETTINGS"]["SUCCESS"], serialized_list[((page - 1) * limit) : ((page * limit) - 1)], len(serialized_list)
				else:
					message = Message["ACCOUNT_SETTINGS"]["UNAUTHORIZED_REQUEST"]
		except Exception as e:
			message = format(e)
		finally:
			return Response({"status": status, "message": message, "data": data, "count": count}, status=200)


# This function is used for altering the status of a Sub-User
class AlterSubUser(APIView):
	@permission_required()
	def post(self, request):
		status, message, act, emp_id, org_id, time_frame, reason = False, "", "", "", "", "", ""
		try:
			user_id, user_type = request.META["user_id"], request.META["user_type"]
			data = request.data
			if (data is []) and (not all(key in data for key in ("action", "emp_id", "time_period", "reason"))):
				message = Message["ACCOUNT_SETTINGS"]["INVALID_REQUEST"]
			else:
				action, emp_id, time_frame, reason = data["action"], data["emp_id"], data["time_period"], data["reason"]
				query_set = EmployerProfile.objects.filter(Q(user_account_id=user_id) & Q(is_sub_user=False))
				if len(query_set) == 1:
					org_id = query_set[0].organization_id
					emp_query = EmployerProfile.objects.filter(Q(user_account_id=emp_id) & Q(organization_id=org_id))
					if len(emp_query) == 1:
						emp_status = emp_query[0].user_status
						if emp_status != "deleted":
							if action == "suspend":
								if emp_status == "suspended":
									message = Message["ACCOUNT_SETTINGS"]["ACCOUNT_SUSPENDED_WARNING"]
								elif time_frame == "":
									message = Message["ACCOUNT_SETTINGS"]["TIME_FRAME_NOT_PROVIDED"]
								else:
									act, status, message = "suspended", True, Message["ACCOUNT_SETTINGS"][
										"ACCOUNT_SUSPENSION_SUCCESS"]
							elif action == "delete":
								act, status, message = "deleted", True, Message["ACCOUNT_SETTINGS"]["ACCOUNT_DELETION_SUCCESS"]
							elif action == "activate":
								if emp_status == "active":
									message = Message["ACCOUNT_SETTINGS"]["ACCOUNT_ACTIVE_WARNING"]
								else:
									act, status, message = "active", True, Message["ACCOUNT_SETTINGS"]["ACCOUNT_ACTIVATION_SUCCESS"]
							else:
								message = Message["ACCOUNT_SETTINGS"]["INVALID_ACTION_REQUEST"]
						else:
							message = Message["ACCOUNT_SETTINGS"]["ACCOUNT_DELETED_WARNING"]
					else:
						message = Message["ACCOUNT_SETTINGS"]["USER_COUNT_CONFLICT"]
				else:
					message = Message["ACCOUNT_SETTINGS"]["UNAUTHORIZED_REQUEST"]
		except Exception as e:
			message = format(e)
		finally:
			if act != "" and status is True:
				emp_status_query = EmployerProfile.objects.filter(Q(user_account_id=emp_id) & Q(organization_id=org_id))
				emp_status_query[0].sub_user_status = act
				emp_status_query[0].account_reason = reason
				curr_time = int(time.time())*1000
				if act == "suspended":
					emp_status_query[0].suspended_date = curr_time
					emp_status_query[0].suspended_till = time_frame
				elif act == "deleted":
					emp_status_query[0].deleted_date = curr_time
				elif act == "active":
					emp_status_query[0].activated_date = curr_time
					act = "activated"
				emp_status_query[0].save()
				emp_email_query = UserAccount.objects.filter(id=emp_id)
				emp_email = emp_email_query[0].email_id
				emp_name = emp_email_query[0].first_name
				mail_body = "Dear " + emp_name + ", <br><br>Your account at Shenzyn has been " + act + "<br><br>Regards,<br>Shenzyn"
				subject = "Shenzyn Account Notification"
				send_email(subject, mail_body, "gupta@selekt.in", [emp_email])
			return Response({"status": status, "message": message}, status=200)


# This function used to create new entry in databased for some drop down details like skill
# After that it will return  id to send respected filled
def account_settings_update_new_values(table_name, value, field_name):
	if value is int:
		return value
	search_type = '__icontains'
	field_nm = field_name + search_type
	info = table_name.objects.filter(**{field_nm: value})
	if info:
		return info[0].id
	else:
		new_value = table_name.objects.create(**{field_name:value})
		return new_value.id


# This function used to excecute raw query in database
# So we have just send query and it will return probable result
def account_settings_raw_query_execute_function(query):
	cursor = connection.cursor()
	cursor.execute(query)
	return cursor.fetchall()

# This function is used for send email otp to requested user for change login email address
# It will check email id is registed with us as  employer or not
# If it is not registered it will sent otp to user mail
# Other wise it will return false with message
class SendEmailOtp(APIView):
    @permission_required()
    def get(self, request):
        try:
            if "email_id" not in request.GET:
                return Response({"status": False, "message": Message["ACCOUNT_SETTINGS"]["CONTACT_DETAILS_EMAIL_OTP_ERROR"]},status=200)
            if is_email_valid(request.GET["email_id"]) and check_email_in_database(request.GET["email_id"]):
                otp = get_random_number()
                otp = str(otp)
                data = {
                    "verification_type": "email_id",
                    "verification_id": request.GET["email_id"],
                    "otp": otp,
                    "otp_status": "N",
                    "timestamp": int(time.time() * 1000)}
                OTPVerification.objects.create(**data)
                subject = "OTP verification"
                body = "Dear "+request.GET["email_id"]+",<br><br>Please enter below OTP to verify your Shenzyn account Login Email address.<br><br>"+otp+"<br>Note: This OTP is valid for the next 2 hours only<br>Regards,<br>Shenzyn"
                send_email(subject,body,"gupta@selekt.in",[request.GET["email_id"]])
                return Response({"status":True, "message":Message["ACCOUNT_SETTINGS"]["CONTACT_DETAILS_EMAIL_OTP_SUCCESS"]},status=200)
            else:
                return Response({"status": False, "message": Message["ACCOUNT_SETTINGS"]["PLEASE_ENTER_VALID_EMAIL"]},status=200)
        except Exception as e:
            return Response({"status": False, "message": format(e)}, status=200)

# This function will validate the email otp
# It will check otp is given in time(as per FRD 2 hours otp validation time)
# If otp is valid it will send success status and change primary email address
class EmailOtpValidate(APIView):
    @permission_required()
    def get(self, request):
        if 'email_id' and 'otp' in request.GET:
            if not is_email_valid(request.GET["email_id"]):
                return Response({"status": False, "message":Message["ACCOUNT_SETTINGS"]["PLEASE_ENTER_VALID_EMAIL"]}, status=200)
            user_id, user_type = request.META["user_id"], request.META["user_type"]
            otp_details = OTPVerification.objects.filter(verification_type="email_id",verification_id=request.GET["email_id"],otp_status="N").order_by("-id")
            if otp_details and str(otp_details[0].otp)==str(request.GET["otp"]):
                if int(time.time()*1000)-(45*1000) <=  int(otp_details[0].timestamp):
                    otp_details[0].otp_status = "V"
                    otp_details[0].save()
                    UserAccount.objects.update_or_create(
                        id=user_id,
                        defaults={
							"id" :user_id,
                            "email_id":request.GET["email_id"],
                            "is_email_verified":True
                        })
                    return Response({"status": True, "message":Message["ACCOUNT_SETTINGS"]["EMAIL_OTP_SUCCESS"]}, status=200)
                else:
                    otp_details[0].otp_status = "E"
                    otp_details[0].save()
                    return Response({"status": False, "message":Message["ACCOUNT_SETTINGS"]["EMAIL_OTP_EXPIRE"]}, status=200)
            else:
                return Response({"status": False, "message":Message["ACCOUNT_SETTINGS"]["OTP_IS_WRONG"]}, status=200)
        else:
            return Response({"status": False, "message":Message["ACCOUNT_SETTINGS"]["OTP_FIELDS_MISSING"]}, status=200)


#This function will check email id is exists in database or not
#It will take email_id and extra one parameter(is_employer or is_job_seeker)
def check_email_in_database(email_id):
    query = UserAccount.objects.filter(email_id=email_id,is_employer=1,is_email_verified=1,employer_profile_status='active')
    serializer = EmployerSerializer(query, many=True).data
    print(serializer);
    # result =[]
    # for value in serializer:
    #     tmp = {}
    #     print(value)
    #     for (index, column) in enumerate(value):
    #         #print(index,column,serializer[0][column])
    #         tmp[column] = value[column]
    #     result.append(tmp)
    # print(result)

    if serializer:
        return False
    else:
        return True  