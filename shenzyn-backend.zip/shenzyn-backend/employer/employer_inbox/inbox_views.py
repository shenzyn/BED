from rest_framework.views import APIView
from django.db.models import Q
from pinkjob.server_settings import *
from employer.decorators import *
from .inbox_models import *
from job_seeker.models import *
from datetime import datetime
from pinkjob.utils import Message
import traceback
# from .homepage_utils import *

base_url = server_settings["base_url"]


# This will provide the posted job cards in the employer inbox
class InboxGenerator(APIView):
	@permission_required()
	def post(self, request):
		# Initial placeholder for class variables
		# user_id, user_type = 2, 1
		status, message, data, count = False, "", [], 0
		try:
			# Fetching id and type from request token
			user_id, user_type = request.META["user_id"], request.META["user_type"]
			req = request.data
			# Initial checking if the received REQUEST contains all required parameters
			if ((req == []) or (
					not all(
						key in req for key in
						("job_title", "applied_on_from", "applied_on_to", "results_per_page", "page")))):
				message = Message["EMPLOYER_INBOX"]["INVALID_REQUEST"]
			else:
				search_phrase, start_date, end_date, limit, page = req["job_title"], req["applied_on_from"], req[
					"applied_on_to"], req["results_per_page"], req["page"]
				# Checking the request data validation clause
				if type(start_date) != type(end_date):
					message = Message["EMPLOYER_INBOX"]["INVALID_PARAMETERS"]
				elif start_date > end_date:
					message = Message["EMPLOYER_INBOX"]["DATE_SELECTION_CONFLICT"]
				else:
					# Filtering jobs which are 'published' by the requesting user
					posted_job_query = PostJobs.objects.filter(Q(user_account_id__id=user_id) & Q(status="Post"))
					# Further filtering based on the start and end date passed in REQUEST
					if start_date != "":
						start_date, end_date = datetime.fromtimestamp(start_date/1000.), datetime.fromtimestamp(
							end_date/1000.)
						posted_job_query = posted_job_query.filter(created_on__range=(start_date, end_date))
					# Further filtering the results if some specific search phrase is passed in the REQUEST
					if search_phrase != "":
						posted_job_query = posted_job_query.filter(job_title__icontains=search_phrase)
					# Checking if some results are still remaining or not after all the previous filtering
					if len(posted_job_query) == 0:
						message = Message["EMPLOYER_INBOX"]["NO_RESULTS"]
					else:
						# Fetching details of all the filtered jobs
						for job_detail in posted_job_query:
							# Attaching job id and job title
							chunk = {"job_id": job_detail.id, "job_title": job_detail.job_title}
							# Querying for posting company name and attaching if found
							company_query = AdvertiseCompanyDetailsJobMapping.objects.filter(job_id__id=job_detail.id)
							if len(company_query) != 0:
								print("printing",company_query[0].advertise_company_details_id.organisation_name.name)
								chunk["company_name"] = company_query[0].advertise_company_details_id.organisation_name.name
							else:
								chunk["company_name"] = "Not Available"
							# Attaching experience range for the job
							chunk["experience"] = {
								"min": job_detail.min_experience,
								"max": job_detail.max_experience
							}
							# Attaching the date the job was published
							chunk["posted_on"] = job_detail.created_on
							# Attaching the count of all application in various stages of selection
							chunk["status"] = {
								"applied": len(JobApplications.objects.filter(job_id__id=job_detail.id)),
								"review": len(JobApplications.objects.filter(
									Q(job_id__id=job_detail.id) & Q(job_application_status_id__id=2))),
								"hold": len(JobApplications.objects.filter(
									Q(job_id__id=job_detail.id) & Q(job_application_status_id__id=3))),
								"shortlisted": len(JobApplications.objects.filter(
									Q(job_id__id=job_detail.id) & Q(job_application_status_id__id=4))),
								"rejected": len(JobApplications.objects.filter(
									Q(job_id__id=job_detail.id) & Q(job_application_status_id__id=5))),
								"later": len(JobApplications.objects.filter(
									Q(job_id__id=job_detail.id) & Q(job_application_status_id__id=6))),
								"offered": len(JobApplications.objects.filter(
									Q(job_id__id=job_detail.id) & Q(job_application_status_id__id=7)))
							}
							data.append(chunk)
						count = len(data)
						# On reaching this point, the operation was successful
						status, message = True, Message["EMPLOYER_INBOX"]["SUCCESS"]
						# Slicing the result for pagination sake
						data = data[(page - 1) * limit: page * limit]
						# Ordering the result in descending value of date of publish of job
						data = sorted(data, key=lambda i: i["posted_on"], reverse=True)
						print(count, len(data))
		except Exception as e:
			traceback.print_exc()
			# Any runtime exception is caught and thrown here
			message = format(e)
		finally:
			# Ultimately the response is sent with appropriate operation success status and explanation message
			# along with finalised data and total count
			return Response({"status": status, "message": message, "data": data, "count": count}, status=200)


# This will provide the list of organizations of all the applicants applying for this job
class AppliedProfilesOrganizationLister(APIView):
	@permission_required()
	def get(self, request, job_id=None):
		# Initial placeholder for class variables
		# user_id, user_type = 1, 2
		status, message, data = False, "", []
		try:
			# Fetching id and type from request token
			user_id, user_type = request.META["user_id"], request.META["user_type"]
			req = request.data
			# Filtering out the applications for the requested job published by requesting user based on its job id
			applicants_list_query = JobApplications.objects.filter(
				Q(job_id__id=job_id) & Q(job_id__user_account_id__id=user_id))
			# Checking if any such results are found or not
			if len(applicants_list_query) == 0:
				message = Message["EMPLOYER_INBOX"]["NO_APPLICANTS"]
			else:
				# Starting a counter variable with '0' index for 'Fresher'
				count = {0: 0}
				for applicant in applicants_list_query:
					# Querying applicants organization details from their experience information
					applicant_experience_info = ExperienceDetails.objects.filter(
						Q(user_account_id__id=applicant.user_account_id.id) & Q(is_current_job=True))
					# If queried applicant belong to some organization, then increasing its count,
					# otherwise recording them as fresher
					if len(applicant_experience_info) != 0:
						if applicant_experience_info[0].company_name.id in count:
							count[applicant_experience_info[0].company_name.id] += 1
						else:
							count[applicant_experience_info[0].company_name.id] = 1
						print(applicant_experience_info[0].company_name.id, applicant_experience_info[0].user_account_id.id)
					else:
						# print(applicant.user_account_id.id)
						count[0] += 1
				for company in count:
					chunk = {}
					if company == 0:
						continue
					# Querying applicants organization info from the previously fetched organization details
					company_name_query = Organizations.objects.filter(id=company)
					chunk['key'] = company_name_query[0].id
					chunk['value'] = company_name_query[0].name
					# Attaching count of candidates with the respective organization name
					chunk["count"] = count[company]
					data.append(chunk)
				# Attaching 'Fresher' count
				data.append({"key": 0, "value": "Fresher", "count": count[0]})
				# Attaching "Total" count
				data.append({"key": "", "value": "All", "count": len(applicants_list_query)})
				# On reaching this point, the operation was successful
				status, message = True, Message["EMPLOYER_INBOX"]["SUCCESS"]
		except Exception as e:
			# Any runtime exception is caught and thrown here
			message = format(e)
		finally:
			# Ultimately the response is sent with appropriate operation success status and explanation message
			# along with finalised data
			return Response({"status": status, "message": message, "data": data}, status=200)


# This will provide the list of applicants applying for the selected job
class AppliedProfilesLister(APIView):
	# Calculates profile match index
	def match_calculation(self, candidate, job_id, skill_ratio):
		# Skill percentage share from previous function call
		skill_percentage = skill_ratio * 50
		# Querying data required for calculation, like candidate's expected salary, experience,
		# and job's min and max ranges
		seeker_detail_query = SeekerProfile.objects.filter(user_account_id__id=candidate)[0]
		job_detail_query = PostJobs.objects.filter(id=job_id)[0]
		# Calculating experience percentage share
		try:
			if seeker_detail_query.experience < job_detail_query.min_experience:
				exp_percentage = ((job_detail_query.max_experience - seeker_detail_query.experience) / (
						job_detail_query.max_experience - job_detail_query.min_experience)) * 20
			else:
				if seeker_detail_query.experience > job_detail_query.max_experience:
					exp_percentage = ((seeker_detail_query.experience - job_detail_query.min_experience) / (
							job_detail_query.max_experience - job_detail_query.min_experience)) * 20
				else:
					exp_percentage = 20
		except:
			# Escaping 'divide by zero' error
			exp_percentage = 0
		# Calculating expected salary percentage share
		try:
			if seeker_detail_query.expected_salary < job_detail_query.min_salary:
				salary_percentage = ((job_detail_query.max_salary - seeker_detail_query.expected_salary) / (
						job_detail_query.max_salary - job_detail_query.min_salary)) * 20
			else:
				if seeker_detail_query.experience > job_detail_query.max_experience:
					salary_percentage = ((seeker_detail_query.expected_salary - job_detail_query.min_experience) / (
							job_detail_query.max_salary - job_detail_query.min_salary)) * 20
				else:
					salary_percentage = 20
		except:
			# Escaping 'divide by zero' error
			salary_percentage = 0
		# Returning summation of all shares (currently adding to 90%)
		return exp_percentage + salary_percentage + skill_percentage

	# Returns the matching and different skill sets of the candidates with the job profile
	def skill_matcher(self, candidate, job_id):
		# Querying skill sets of seeker and required job profile
		seeker_skills_query = SeekerSkillSet.objects.filter(user_account_id__id=candidate)
		job_skills_query = DesireCandidateProfileSkills.objects.filter(job_id__id=job_id)
		seeker_skills = [iter.skill_set_id.id for iter in seeker_skills_query]
		job_skills = [iter.qualities.id for iter in job_skills_query]
		# Filtering actual seeker and job required skill
		seeker_skill_set_query = SkillSet.objects.filter(id__in=seeker_skills)
		job_skill_set_query = SkillSet.objects.filter(id__in=job_skills)
		# Fetching respective names of skills
		seeker_skills_name = [i.skill_set_name for i in seeker_skill_set_query]
		job_skills_name = [i.skill_set_name for i in job_skill_set_query]
		# Grouping matched skills and remaining sills (other skills)
		matched_skill = list(set(seeker_skills_name) & set(job_skills_name))
		other_skill = list(set(job_skills_name) - set(seeker_skills_name))
		# Calculating skill match/total ratio, for future use in match index calculation
		ratio = len(matched_skill) / len(job_skills_name)
		# Returning all the results
		return matched_skill, other_skill, ratio

	@permission_required()
	def post(self, request, job_id=None):
		# Initial placeholder for class variables
		# user_id, user_type = 1, 2
		status, message, data, count, job_title = False, "", [], 0, ""
		try:
			# Fetching id and type from request token
			user_id, user_type = request.META["user_id"], request.META["user_type"]
			req = request.data
			# Initial checking if the received REQUEST contains all required parameters
			if ((req == []) or (
					not all(
						key in req for key in (
								"search_key", "start_date", "end_date", "application_status", "location",
								"min_experience", "max_experience", "min_expected_salary", "max_expected_salary",
								"min_current_salary", "max_current_salary", "organization", "results_per_page",
								"page")))):
				message = Message["EMPLOYER_INBOX"]["INVALID_REQUEST"]
			else:
				search_phrase, start_date, end_date, application_status, location, min_experience, max_experience, \
					min_expected_salary, max_expected_salary, min_current_salary, max_current_salary, organization, \
					limit, page = \
					req["search_key"], req["start_date"], req["end_date"], req["application_status"], req["location"], \
					req["min_experience"], req["max_experience"], req["min_expected_salary"], \
					req["max_expected_salary"], req["min_current_salary"], req["max_current_salary"], \
					req["organization"],req["results_per_page"], req["page"]
				# Checking the request data validation clause --
				# Both start and end should be present/ absent and end date must not be less than start date
				if (start_date > end_date) or (start_date != "" and end_date == "") or (
						start_date == "" and end_date != ""):
					message = Message["EMPLOYER_INBOX"]["INVALID_DATE_RANGE"]
				# Maximum 4 locations can be passed for filtering
				elif len(location) > 4:
					message = Message["EMPLOYER_INBOX"]["LOCATION_SELECTION_EXCEEDS"]
				# All Minimum values must be not more than Maximum
				elif min_experience > max_experience:
					message = Message["EMPLOYER_INBOX"]["EXPERIENCE_MIN_MAX_CONFLICT"]
				elif min_expected_salary > max_expected_salary:
					message = Message["EMPLOYER_INBOX"]["CTC_MIN_MAX_CONFLICT"]
				elif min_current_salary > max_current_salary:
					message = Message["EMPLOYER_INBOX"]["CTC_MIN_MAX_CONFLICT"]
				# Validating acceptable input range for values
				elif type(min_experience) != type(max_experience) or type(min_expected_salary) != type(
						max_expected_salary) or type(min_current_salary) != type(max_current_salary) or type(
						start_date) != type(end_date):
					message = Message["EMPLOYER_INBOX"]["INVALID_PARAMETERS"]
				elif not all((0.1 <= float(val) <= 50) if val != "" else True for val in (
						min_experience, max_experience)):
					message = Message["EMPLOYER_INBOX"]["EXPERIENCE_NOT_IN_RANGE"]
				elif not all((0.1 <= float(val) <= 100) if val != "" else True for val in (
						min_current_salary, min_expected_salary, max_current_salary, max_expected_salary)):
					message = Message["EMPLOYER_INBOX"]["SALARY_NOT_IN_RANGE"]
				else:
					# Filtering out the application for the requested job published by requesting user
					# based on  its job id
					job_title = PostJobs.objects.filter(id=job_id)
					job_title = job_title[0].job_title if len(job_title) == 1 else "No Title Available"
					applicant_id_lister_query = JobApplications.objects.filter(
						Q(job_id__id=job_id) & Q(job_id__user_account_id__id=user_id))
					# Filtering based on the search phrase passed
					if search_phrase != "":
						applicant_id_lister_query = applicant_id_lister_query.filter(Q(
							user_account_id__first_name__icontains=search_phrase) | Q(
							user_account_id__last_name__icontains=search_phrase))
					# Filtering applications based on application status, if passed in the REQUEST
					if len(application_status) != 0:
						# Reducing application status to a list for ease of future use
						application_status = [stat["key"] for stat in application_status]
						applicant_id_lister_query = applicant_id_lister_query.filter(
							job_application_status_id__id__in=application_status)
					# Further filtering based on the start and end date, if passed in REQUEST
					if start_date != "":
						start_date, end_date = datetime.fromtimestamp(start_date/1000.), datetime.fromtimestamp(
							end_date/1000.)
						applicant_id_lister_query = applicant_id_lister_query.filter(
							application_date__range=(start_date, end_date))
					# Checking if some results are still remaining or not after all the previous filtering
					if len(applicant_id_lister_query) == 0:
						message = Message["EMPLOYER_INBOX"]["NO_RESULTS"]
					else:
						# Reducing filtered applicants id into a list for simplifying further use
						applicants_id = [applicant.user_account_id.id for applicant in applicant_id_lister_query]
						# Placeholder to store filtered candidates ids
						filtered_candidates = applicants_id
						# Querying applicants profile
						seeker_profile_fetch_query = SeekerProfile.objects.filter(user_account_id__id__in=applicants_id)
						seeker_experience_detail_fetch_query = ExperienceDetails.objects.filter(
							Q(user_account_id__id__in=applicants_id) & Q(is_current_job=True))
						# Filtering based on location
						if len(location) != 0:
							location = [loc["key"] for loc in location]
							seeker_profile_fetch_query = seeker_profile_fetch_query.filter(hometown__id__in=location)
							filtered_candidates = [seeker.user_account_id.id for seeker in seeker_profile_fetch_query]
						# Checking if some results are still remaining or not after all the previous filtering
						if len(filtered_candidates) != 0:
							print("c 1", filtered_candidates)
							# Filtering based on the organization passed in the REQUEST
							if len(organization) != 0:

								# Reducing organization status to a list for ease of future use
								organization = [org["key"] for org in organization]
								print("C2", organization)
								# Filtering for only 'Fresher'
								if len(organization) == 1 and organization[0] == 0:
									print("c21")
									seeker_profile_fetch_query = seeker_profile_fetch_query.filter(is_fresher=True)
									seeker_experience_detail_fetch_query = ""
									# Filtering only fresher candidate
									filtered_candidates = [
										seeker.user_account_id.id for seeker in seeker_profile_fetch_query]
								# Filtering for 'Experienced'
								elif len(organization) == 1 and 0 not in organization:
									print("c22", organization)
									seeker_profile_fetch_query = seeker_profile_fetch_query.filter(is_fresher=False)
									print(len(seeker_profile_fetch_query))
									seeker_experience_detail_fetch_query = seeker_experience_detail_fetch_query\
										.filter(company_name__id__in=organization)
									print(len(seeker_experience_detail_fetch_query))
									matched_seeker_profile_id = [
										i.user_account_id.id for i in seeker_profile_fetch_query]
									matched_experienced_profile_id = [
										i.user_account_id.id for i in seeker_experience_detail_fetch_query]
									# Filtering candidates belonging to passed organization
									filtered_candidates = list(set(matched_seeker_profile_id) & set(
										matched_experienced_profile_id))
									print(filtered_candidates, matched_seeker_profile_id, matched_experienced_profile_id)
								# Filtering for 'Mixed'
								else:
									print("c23")
									organization.remove(0)
									seeker_experience_detail_fetch_query = seeker_experience_detail_fetch_query.filter(
										company_name__id__in=organization)
									candidates_of_undesired_organization = ExperienceDetails.objects.exclude(
										company_name__id__in=organization)
									matched_seeker_profile_id = [
										i.user_account_id.id for i in seeker_profile_fetch_query]
									# Clustering candidates from undesired organizations
									undesired_candidates_id = [
										c.user_account_id.id for c in candidates_of_undesired_organization]
									# Getting all candidates except those belonging to undesired organizations
									filtered_candidates = list(set(matched_seeker_profile_id) - set(
										undesired_candidates_id))
							# Checking if some results are still remaining or not after all the previous filtering
							if len(filtered_candidates) != 0:
								# Filtering based on parameters for only experienced candidate
								if min_current_salary != "":
									if seeker_experience_detail_fetch_query != "":
										# Filtering based on current salary
										seeker_experience_detail_fetch_query = seeker_experience_detail_fetch_query\
											.filter(annual_salary__range=(min_current_salary, max_current_salary))
									else:
										filtered_candidates = []
								# Checking if some results are still remaining or not after all the previous filtering
								if len(filtered_candidates) != 0:
									seeker_profile_fetch_query = seeker_profile_fetch_query.filter(
										user_account_id__id__in=filtered_candidates)
									
									# Filtering based on experience LYING IN THE REQUIRED RANGE
									if min_experience != "":
										seeker_profile_fetch_query = seeker_profile_fetch_query.filter(
											experience__range=(min_experience, max_experience))
										matched_seeker_profile_id = [
											i.user_account_id.id for i in seeker_profile_fetch_query]
										filtered_candidates = list(set(filtered_candidates) & set(
											matched_seeker_profile_id))
									# Checking if some results are still remaining or not
									# after all the previous filtering
									if len(filtered_candidates) != 0:
										# Filtering based on expected salary
										if min_expected_salary != "":
											# Querying desired profiles applied for this job and salary lying
											# in the required range
											salary_filtering_query = DesiredCandidateProfile.objects.filter(Q(
												user_account_id__id__in=filtered_candidates) & Q(
												expected_salary_in_lacs__range=(
													min_expected_salary, max_expected_salary)))
											filtered_candidates = [
												i.user_account_id.id for i in salary_filtering_query]
										# Checking if some results are still remaining or not
										# after all the previous filtering
										if len(filtered_candidates) != 0:
											# Preparing data of all filtered candidates to be sent
											for candidate in filtered_candidates:
												print(candidate,"candidate");
												candidate_seeker_profile = seeker_profile_fetch_query.filter(
													user_account_id__id=candidate).first()
												print(candidate_seeker_profile)
												if candidate_seeker_profile:
													detailer = {}
													detailer["applicant_id"] = candidate
													detailer["applicant_name"] = candidate_seeker_profile.user_account_id\
														.first_name + " " + candidate_seeker_profile.user_account_id\
														.last_name
													experience = "Fresher"

													detailer["job_description"] = ""
													detailer["current_organization"] = ""
													detailer["current_salary"] = ""
													if seeker_experience_detail_fetch_query != "" and len(seeker_experience_detail_fetch_query) != 0:
														
														candidate_experience_profile = seeker_experience_detail_fetch_query\
															.filter(user_account_id__id=candidate)
														# Placeholder for holding response format
														
														
														print(candidate_experience_profile);
														if len(candidate_experience_profile) != 0:

															detailer["job_description"] = candidate_seeker_profile.job_title\
																.name if hasattr(candidate_seeker_profile,"job_title") else ""
															detailer["current_organization"] = candidate_experience_profile\
																.company_name.company_name if hasattr(candidate_experience_profile,"company_name") else ""
															detailer["current_salary"] = candidate_experience_profile\
																.annual_salary if hasattr(candidate_experience_profile,"annual_salary") else ""
														
														print(candidate_seeker_profile.experience_in_years)
														candidate_experience_profile = candidate_experience_profile[0]
														try:
															if hasattr(
																	candidate_seeker_profile, 'experience_in_years') and \
																	candidate_seeker_profile.experience_in_years:
																experience = str(candidate_seeker_profile.experience_in_years) + "."\
																			+ str(candidate_experience_profile.experience_in_months)
															elif hasattr(candidate_seeker_profile, 'experience_in_months') and \
																	candidate_experience_profile.experience_in_months:
																experience = 0  + "." + candidate_experience_profile\
																	.experience_in_months
														except AttributeError:
															experience = experience
													
													if experience == "Fresher":
														try:
															experience_in_years = candidate_seeker_profile.experience_in_years
															experience_in_months = candidate_seeker_profile.experience_in_months
														except AttributeError:
															experience_in_years = 0
															experience_in_months = 0
														print(experience_in_months,experience_in_years)
														if experience_in_months and experience_in_months and (
																experience_in_months != 0 or experience_in_years != 0):
															experience = "Experienced ( " + str(experience_in_months)+" years & " + str(experience_in_years) + " months )"
															
														else:
															experience = "Fresher"
													detailer["experience"] = experience
													detailer["applied_on"] = applicant_id_lister_query.filter(
														user_account_id__id=candidate)[0].application_date
													detailer["status"] = applicant_id_lister_query.filter(
														user_account_id__id=candidate)[0].job_application_status_id.status
													print("Came Here")
													# Calling custom function for matching and different skill
													detailer["matching_skills"], detailer["other_skills"], tmp_skill_ratio \
														= self.skill_matcher(candidate, job_id)
													# Calling custom function for profile match calculation
													detailer["profile_match"] = self.match_calculation(
														candidate, job_id, tmp_skill_ratio)
													data.append(detailer)
											# Count of all finalised data
											count = len(data)
											# Slicing the result for pagination sake
											data = data[(page - 1) * limit: page * limit]
											# Ordering the result in descending value of date of publish of job
											data = sorted(data, key=lambda i: i["applied_on"], reverse=True)
											# On reaching this point, the operation was successful
											status, message = True, Message["EMPLOYER_INBOX"]["SUCCESS"]
										else:
											message = Message["EMPLOYER_INBOX"]["NO_RESULTS"]
									else:
										message = Message["EMPLOYER_INBOX"]["NO_RESULTS"]
								else:
									message = Message["EMPLOYER_INBOX"]["NO_RESULTS"]
							else:
								message = Message["EMPLOYER_INBOX"]["NO_RESULTS"]
						else:
							message = Message["EMPLOYER_INBOX"]["NO_RESULTS"]
		except Exception as e:
			# Any runtime exception is caught and thrown here
			print(e)
			traceback.print_exc()
			message = format(e)
		finally:
			# Ultimately the response is sent with appropriate operation success status and explanation message
			# along with finalised data and total count
			return Response({
				"status": status, "message": message, "data": data, "count": count, "job_title": job_title}, status=200)


# This will provide the profile details of the candidate selected, who applied for the preciously selected job
class ProfileDetailsGenerator(APIView):
	@permission_required()
	def get(self, request, job_id=None, candidate_id=None):
		# Initial placeholder for class variables
		# user_id, user_type = 1, 2
		status, message, data, experienced, working = False, "", {}, False, False
		try:
			# Fetching id and type from request token
			user_id, user_type = request.META["user_id"], request.META["user_type"]
			print(job_id, candidate_id)
			req = request.data
			# Initial checking if the received REQUEST contains all required parameters
			seeker_profile_query = SeekerProfile.objects.filter(user_account_id__id=candidate_id)
			if len(seeker_profile_query) == 0:
				message = "Sorry"
			else:
				seeker_profile_query = seeker_profile_query[0]
				all_work_detail_query = ExperienceDetails.objects.filter(user_account_id__id=candidate_id)
				current_work_detail_query =  all_work_detail_query.filter(is_current_job=True)
				if len(current_work_detail_query) != 0:
					current_work_detail_query = current_work_detail_query[0]
					working = True
				data = {
					"snippet": {},
					"basic_profile": {},
					"resume_headline": "",
					"profile_summary": "",
					"skills": [],
					"employment_details": [],
					"training_internship": {
						"training": [],
						"internship": []
					},
					"education": [],
					"technologies": [],
					"projects": [],
					"achievements": {
						"online_profile": [],
						"work_sample": [],
						"publication": [],
						"presentation": [],
						"patent": [],
						"certification": [],
						"reward": []
					},
					"desired_profile": {},
					"profile_details": {},
					"resumes": {},
					"application_status": "Applied"
				}
				data["snippet"]["profile_image"] = seeker_profile_query.profile_image_path.url if hasattr(
					seeker_profile_query,"profile_image_path") else ""
				data["snippet"]["full_name"] = seeker_profile_query.user_account_id.first_name if seeker_profile_query\
					.user_account_id.first_name else "" + " " \
					+ seeker_profile_query.user_account_id.middle_name if seeker_profile_query.user_account_id\
					.middle_name else "" + " " + seeker_profile_query.user_account_id\
					.last_name if seeker_profile_query.user_account_id.last_name else ""
				if working:
					data["snippet"]["title"] = current_work_detail_query.job_title.name 
				else:
					data["snippet"]["title"] = ""#seeker_profile_query.desired_career_profile.job_title.name
				data["snippet"]["email"] = seeker_profile_query.user_account_id.email_id
				location = ""
				try:
					location = seeker_profile_query.hometown.city + ", " + seeker_profile_query.hometown\
						.country
				except AttributeError:
					location = ""
				data["snippet"]["location"] = location;
				data['resumes']['resume_document1'] = seeker_profile_query.resume_document1.url if seeker_profile_query\
					.resume_document1 else ""
				data['resumes']['resume_video1'] = seeker_profile_query.resume_video1.url if seeker_profile_query\
					.resume_video1 else ""
				data['resumes']['resume_document2'] = seeker_profile_query.resume_document2.url if seeker_profile_query\
					.resume_document2 else ""
				data['resumes']['resume_video2'] = seeker_profile_query.resume_video2.url if seeker_profile_query\
					.resume_video2 else ""
				if data['resumes']['resume_video1']:
					data['resumes']['resume_video1'] =data['resumes']['resume_video1'].split("pinkjob/media/")[1].replace("%3A",":/") if data['resumes']['resume_video1'].__contains__("shenzyn.com") else data['resumes']['resume_video1'];
				if data['resumes']['resume_video2']:
					data['resumes']['resume_video2'] =data['resumes']['resume_video2'].split("pinkjob/media/")[1].replace("%3A",":/") if data['resumes']['resume_video2'].__contains__("shenzyn.com") else data['resumes']['resume_video2'];
				experience_in_years = 0
				experience_in_months = 0
				try:
					experience_in_years = seeker_profile_query.experience_in_years
					experience_in_months = seeker_profile_query.experience_in_months
				except AttributeError:
					experience_in_years = experience_in_years
					experience_in_months = experience_in_months
				print(experience_in_months,experience_in_years)
				if experience_in_months and experience_in_months and (
						experience_in_months != 0 or experience_in_years != 0):
					data["basic_profile"]["experience"] = "Experienced ( " + str(experience_in_months)+" years & " + str(experience_in_years) + " months )"
					experienced = True
				else:
					data["basic_profile"]["experience"] = "Fresher"
				if working:
					currency_sign = current_work_detail_query.currency if hasattr(current_work_detail_query,"currency") else ""
					salary_amt = current_work_detail_query.annual_salary if hasattr(current_work_detail_query,"annual_salary") else "0"
					data["basic_profile"]["annual_salary"] = str(currency_sign) + " " + str(salary_amt) + " lacs"
				data["basic_profile"]["mobile_number"] = seeker_profile_query.user_account_id.mobile_number
				data['resume_headline'] = seeker_profile_query.resume_headline
				data['profile_summary'] = seeker_profile_query.profile_summary
				seeker_skill_query = SeekerSkillSet.objects.filter(user_account_id__id=candidate_id)
				if len(seeker_skill_query) != 0:
					data["skills"] = [set.skill_set_id.skill_set_name for set in seeker_skill_query]
				print("Out work ", len(all_work_detail_query))
				for work in all_work_detail_query:
					print("In work")
					work_info = {}
					work_info["job_title"] = work.job_title.name if work.job_title else ""
					work_info["organization"] = work.company_name.name if work.company_name else ""
					work_info["currently_working"] = work.is_current_job
					work_info["start_date"] = work.start_date
					work_info["end_date"] = work.end_date
					work_info["organization_type"] = work.organization_type
					work_info["role"] = work.description
					if work.is_current_job:
						work_info["notice_period"] = work.notice_period
						work_info["last_working_day"] = work.last_working_day
						work_info["designation_offered"] = work.offered_job_title.name if hasattr(work,"offered_job_title") and work.offered_job_title  else ""
						work_info["next_employer"] = work.offered_company_name.company_name if hasattr(work,"offered_company_name") and work.offered_company_name else ""
						work_info["buy_out_option"] = work.is_buy_out_option if hasattr(work,"is_buy_out_option") else False;
						work_info["notice_period_negotiable"] = work.is_notice_negotiable if hasattr(work,"is_notice_negotiable") else False;
					data['employment_details'].append(work_info)
				data['employment_details'] = sorted(data['employment_details'], key=lambda i: i[
					"start_date"], reverse=True)
				education_detail = EducationalDetails.objects.filter(user_account_id__id=candidate_id)
				if len(education_detail) != 0:
					for education in education_detail:
						edu_info = {}
						if education.board:
							edu_info['qualifications'] = education.degree_name.qualification_name
							edu_info['board'] = education.board.board_name
							edu_info['end_date'] = education.passed_out_year
							edu_info['medium'] = education.medium.medium_name
							edu_info['marks'] = education.percentage
						else:
							edu_info['qualifications'] = education.degree_name.qualification_name
							edu_info['major'] = education.major.major_name
							edu_info['university'] = education.university.university_name
							edu_info['institute'] = education.institute.institute_name
							edu_info['start_date'] = education.start_date
							edu_info['end_date'] = education.completion_date
							edu_info['grading_date'] = education.grading_system.grading_system_name
							edu_info['marks'] = education.percentage
						if edu_info != {}:
							data['education'].append(edu_info)
					data['education'] = sorted(data['education'], key=lambda i: i["end_date"], reverse=True)
				technology_detail = Technologies.objects.filter(user_account_id__id=candidate_id)
				if len(technology_detail) != 0:
					for technology in technology_detail:
						tech_info = {}
						tech_info['technology'] = technology.technology_name
						tech_info['experience_in_years'] = technology.experience_in_years
						tech_info['experience_in_months'] = technology.experience_in_months
						if technology.technology_name:
							data['technologies'].append(tech_info)
					data['technologies'] = sorted(data['technologies'], key=lambda i: i[
						"experience_in_months"], reverse=True)
					data['technologies'] = sorted(data['technologies'], key=lambda i: i[
						"experience_in_years"], reverse=True)
				projects_detail = ProjectDetails.objects.filter(user_account_id__id=candidate_id)
				if len(projects_detail) != 0:
					for project in projects_detail:
						project_info = {}
						project_info['title'] = project.project_title
						project_info['role'] = project.job_title.name
						project_info['qualifications'] = project.qualifications
						project_info['client'] = project.organization.name
						project_info['status'] = project.status
						project_info['start_date'] = project.start_date
						project_info['end_date'] = project.end_date
						project_info['location'] = project.project_location
						project_info['details'] = project.project_description
						project_info['site'] = project.project_site
						project_info['nature'] = project.project_nature
						project_info['team_size'] = project.team_size
						project_info['team_role'] = project.team_role.name
						project_info['description'] = project.role_description
						project_info['document'] = project.document.url
						project_info['skills'] =[]
						project_skill = ProjectSkillSetMapping.objects.filter(project_id__id=project.id)
						if len(project_skill) != 0:
							project_info['skills'] = [skill.skill_set_id.skill_set_name for skill in project_skill]
				training_detail = TrainingDetails.objects.filter(user_account_id__id=candidate_id)
				if len(training_detail) != 0:
					for training in training_detail:
						training_info = {}
						training_info['name'] = training.course_name
						training_info['institute'] = training.institute_name.institute_name
						training_info['start_date'] = training.start_date
						training_info['end_date'] = training.end_date
						if training.course_name:
							data['training_internship']['training'].append(training_info)
					data['training_internship']['training'] = sorted(data['training_internship'][
						'training'], key=lambda i: i["end_date"], reverse=True)
				internship_detail = InternshipDetails.objects.filter(user_account_id__id=candidate_id)
				if len(internship_detail) != 0:
					for internship in internship_detail:
						intern_info = {}
						intern_info['role'] = internship.job_title.name
						intern_info['company'] = internship.company_name.name
						intern_info['tenure_in_years'] = internship.tenure_in_years
						intern_info['tenure_in_months'] = internship.tenure_in_months
						data['training_internship']['internship'].append(intern_info)
					data['training_internship']['internship'] = sorted(data['training_internship'][
						'internship'], key=lambda i: i["tenure_in_months"], reverse=True)
					data['training_internship']['internship'] = sorted(data['training_internship'][
						'internship'], key=lambda i: i["tenure_in_years"], reverse=True)
				online_profile_detail = OnlineProfiles.objects.filter(user_account_id__id=candidate_id)
				if len(online_profile_detail) != 0:
					for profile in online_profile_detail:
						profile_info = {}
						profile_info['profile'] = profile.profile_name
						profile_info['url'] = profile.url
						profile_info['description'] = profile.description
						data['achievements']['online_profile'].append(profile_info)
				work_sample_detail = WorkSamples.objects.filter(user_account_id__id=candidate_id)
				if len(work_sample_detail) != 0:
					for sample in work_sample_detail:
						work_sample_info = {}
						work_sample_info['title'] = sample.work_title
						work_sample_info['url'] = sample.url
						work_sample_info['currently_working'] = sample.currently_working
						work_sample_info['start_date'] = sample.start_date
						work_sample_info['end_date'] = sample.end_date
						work_sample_info['description'] = sample.description
						data['achievements']['work_sample'].append(work_sample_info)
				publication_detail = ResearchPapers.objects.filter(user_account_id__id=candidate_id)
				if len(publication_detail) != 0:
					for publish in publication_detail:
						pubished_info = {}
						pubished_info['title'] = publish.title
						pubished_info['url'] = publish.url
						pubished_info['currently_working'] = publish.is_currently_working
						pubished_info['start_date'] = publish.start_date
						pubished_info['end_date'] = publish.end_date
						pubished_info['duration_in_year'] = publish.duration_in_years
						pubished_info['duration_in_month'] = publish.duration_in_months
						pubished_info['description'] = publish.description
						if publish.title:
							data['achievements']['publications'].append(pubished_info)
					data['achievements']['publications'] = sorted(data['achievements'][
						'publications'], key=lambda i: i["duration_in_month"], reverse=True)
					data['achievements']['publications'] = sorted(data['achievements'][
						'publications'], key=lambda i: i["duration_in_year"], reverse=True)
				presentation_detail = Presentations.objects.filter(user_account_id__id=candidate_id)
				if len(presentation_detail) != 0:
					for ppt in presentation_detail:
						ppt_info = {}
						ppt_info['title'] = ppt.title
						ppt_info['url'] = ppt.url
						ppt_info['description'] = ppt.description
						if ppt.title:
							data['achievements']['presentations'].append(ppt_info)
				patent_detail = Patents.objects.filter(user_account_id__id=candidate_id)
				if len(patent_detail) != 0:
					for patent in patent_detail:
						patent_info = {}
						patent_info['title'] = patent.title
						patent_info['url'] = patent.url
						patent_info['office'] = patent.patent_office
						patent_info['issued'] = patent.status
						patent_info['application_number'] = patent.application_number
						patent_info['issued_date_in_year'] = patent.issue_date_in_years
						patent_info['issued_date_in_month'] = patent.issue_date_in_months
						patent_info['description'] = patent.description
						if patent.title:
							data['achievements']['patent'].append(patent_info)
					data['achievements']['patent'] = sorted(data['achievements'][
						'publications'], key=lambda i: i["issued_date_in_month"], reverse=True)
					data['achievements']['patent'] = sorted(data['achievements'][
						'publications'], key=lambda i: i["issued_date_in_year"], reverse=True)
				certification_detail = Certifications.objects.filter(user_account_id__id=candidate_id)
				if len(certification_detail) != 0:
					for certificate in certification_detail:
						certify_info = {}
						certify_info['name'] = certificate.certificate_names
						certify_info['body'] = certificate.certificate_body
						certify_info['year'] = certificate.year
						if certificate.certificate_names:
							data['achievements']['certification'].append(certify_info)
					data['achievements']['certification'] = sorted(data['achievements'][
						'certification'], key=lambda i: i['year'], reverse=True)
				reward_detail = Rewards.objects.filter(user_account_id__id=candidate_id)
				if len(reward_detail) != 0:
					for reward in reward_detail:
						reward_info = {}
						reward_info['title'] = reward.title
						reward_info['description'] = reward.description
						if reward.title:
							data['achievements']['reward'].append(reward_info)
				desired_profile = DesiredCandidateProfile.objects.filter(user_account_id__id=candidate_id)
				if len(desired_profile) != 0:
					desired_profile = desired_profile[0]
					desired_profile_info = {}
					desired_profile_info['industry'] = desired_profile.industry.name
					desired_profile_info['functional_area'] = desired_profile.functional_area.name
					desired_profile_info['role'] = desired_profile.job_title.name
					desired_profile_info['job_type'] = desired_profile.job_type
					desired_profile_info['shift'] = desired_profile.desired_shift + "" + desired_profile.shift_time
					desired_profile_info['availability'] = desired_profile.availability
					desired_profile_info['available_month'] = desired_profile.availability_month
					desired_profile_info['available_year'] = desired_profile.availability_year
					desired_profile_info['expected_salary'] = {
						'currency': desired_profile.expected_salary_currency,
						'value': desired_profile.expected_salary_in_lacs,
					}
					desired_location_query = DesiredProfileLocationMapping.objects.filter(
						desired_profile_id__id=desired_profile.id)
					desired_profile_info['location'] = [
						location.location.city + ", " + location.location.country for location in desired_location_query]
					data['desired_profile'] = desired_profile_info
				data['personal_details'] = {
					"birth_date": seeker_profile_query.user_account_id.dob,
					"gender": "",
					"address": seeker_profile_query.user_account_id.address,
					"pincode": seeker_profile_query.user_account_id.pincode,
					"hometown": seeker_profile_query.hometown.city if seeker_profile_query.hometown else "",
					"passport_number": seeker_profile_query.passport_number,
					"marital_status": seeker_profile_query.marital_status,
					"category": seeker_profile_query.category,
					"differently_abled": seeker_profile_query.differently_abled,
					"language": []
				}
				language_details = LanguageDetails.objects.filter(user_account_id__id=candidate_id)
				if len(language_details) != 0:
					for language in language_details:
						lang_info = {}
						lang_info['language'] = language.language.language_name
						lang_info['read'] = language.read
						lang_info['write'] = language.write
						lang_info['speak'] = language.speak
						data['personal_details']['language'].append(lang_info)
				
				
				application_status_query = JobApplications.objects.filter(Q(job_id__id=job_id) & Q(user_account_id__id=candidate_id)).first()
				try:
					data["application_status"] = application_status_query.job_application_status_id.status
				except Exception as e:
					data["application_status"] = "Applied"
				# On reaching this point, the operation was successful
				status, message = True, Message["EMPLOYER_INBOX"]["SUCCESS"]
		except Exception as e:
			# Any runtime exception is caught and thrown here
			traceback.print_exc()
			message = format(e)
		finally:
			# Ultimately the response is sent with appropriate operation success status and explanation message
			# along with finalised data and total count
			return Response({
				"status": status, "message": message, "is_experienced": experienced, "data": data}, status=200)


# This API will handle the change of application status by the user(employer) of the selected job_seeker
class ProfileStatusChanger(APIView):
	@permission_required()
	def post(self, request, job_id=None, candidate_id=None):
		# Initial placeholder for class variables
		# user_id, user_type = 1, 2
		status, message, data = False, "", []
		try:
			# Fetching id and type from request token
			user_id, user_type = request.META["user_id"], request.META["user_type"]
			req = request.data
			# Initial checking if the received REQUEST contains all required parameters
			if (req == []) or ("status" not in req):
				message = Message["EMPLOYER_INBOX"]["INVALID_REQUEST"]
			else:
				status_id = req["status"]["key"]
				status_query = ApplicationStatusLabels.objects.filter(id=status_id).first()
				application_query = JobApplications.objects.filter(Q(job_id__id=job_id) & Q(
					user_account_id__id=candidate_id)).first()
				try:
					application_query.job_application_status_id = status_query
					application_query.save()
					JobApplicationStatus.objects.create(
						job_application_id=application_query, job_application_status_id=status_query, action_date=datetime
						.now())
				except Exception as e:
					message = format(e)
				else:
					# On reaching this point, the operation was successful
					status, message = True, Message["EMPLOYER_INBOX"]["SUCCESS"]

		except Exception as e:
			# Any runtime exception is caught and thrown here
			message = format(e)
		finally:
			# Ultimately the response is sent with appropriate operation success status and explanation message
			# along with finalised data and total count
			return Response({"status": status, "message": message, "data": data}, status=200)


# This API returns the list of all valid status
class GetStatusCodes(APIView):
	def get(self, request):
		status, message, data = False, "", []
		try:
			# Fetch all applcaiton status labels
			status_labels = ApplicationStatusLabels.objects.all()
			for label in status_labels:
				# Creating a dictionary with key and name of each status for future use
				lbl_info = {
					"key": label.id,
					"value": label.status
				}
				data.append(lbl_info)
			# On reaching this point, operation is successful
			status, message = True, "Success"
		except Exception as e:
			# Any runtime exception is caught here
			message = format(e)
		finally:
			# Ultimately the response is sent
			return Response({"status": status, "message": message, "data": data}, status=200)


# This API returns the list of all locations of the applied candidates
class AppliedProfilesLocationLister(APIView):
	@permission_required()
	def get(self, request, job_id=None):
		# Initial placeholder for class variables
		# user_id, user_type = 1, 2
		status, message, data = False, "", []
		try:
			# Fetching id and type from request token
			user_id, user_type = request.META["user_id"], request.META["user_type"]
			req = request.data
			# Filtering out the applications for the requested job published by requesting user based on its job id
			applicants_list_query = JobApplications.objects.filter(
				Q(job_id__id=job_id) & Q(job_id__user_account_id__id=user_id))
			# Checking if any such results are found or not
			if len(applicants_list_query) == 0:
				message = Message["EMPLOYER_INBOX"]["NO_APPLICANTS"]
			else:
				# Starting a counter variable with '0' index for 'Fresher'
				count = {0: 0}
				for applicant in applicants_list_query:
					# Querying applicants organization details from their experience information
					applicant_info = SeekerProfile.objects.filter(
						user_account_id__id=applicant.user_account_id.id)
					# If queried applicant belong to some organization, then increasing its count,
					# otherwise recording them as fresher
					if len(applicant_info) != 0:
						if applicant_info[0].hometown.id in count:
							count[applicant_info[0].hometown.id] += 1
						else:
							count[applicant_info[0].hometown.id] = 1
					else:
						count[0] += 1
				for city in count:
					chunk = {}
					if city == 0:
						continue
					# Querying applicants organization info from the previously fetched organization details
					city_name_query = Location.objects.filter(id=city)
					chunk['key'] = city_name_query[0].id
					chunk['value'] = city_name_query[0].city
					# Attaching count of candidates with the respective organization name
					chunk["count"] = count[city]
					data.append(chunk)
				# Attaching "Total" count
				data.append({"key": "", "value": "All", "count": len(applicants_list_query)})
				# On reaching this point, the operation was successful
				status, message = True, Message["EMPLOYER_INBOX"]["SUCCESS"]
		except Exception as e:
			# Any runtime exception is caught and thrown here
			message = format(e)
		finally:
			# Ultimately the response is sent with appropriate operation success status and explanation message
			# along with finalised data
			return Response({"status": status, "message": message, "data": data}, status=200)


