from employer.post_jobs.post_jobs_models import *
from employer.models import UserAccount


# Relation to store various stages of status in a selection process like "Applied","In Review","On Hold","Offered",etc.
class ApplicationStatusLabels(models.Model):
	status = models.CharField(max_length=50, null=True)


# Relation to store the event of a seeker's application to a published job
class JobApplications(models.Model):
	job_id = models.ForeignKey(PostJobs, related_name="job_id_application_activity", on_delete=models.CASCADE)
	user_account_id = models.ForeignKey(UserAccount, related_name="user_account_id_application_activity",
										on_delete=models.CASCADE)
	job_application_status_id = models.ForeignKey(ApplicationStatusLabels,
										related_name="job_application_status_id_application_activity",
										default=1, on_delete=models.CASCADE)
	application_date = models.DateTimeField(null=True)


# Relation to store each event of change in a seeker's/applicant's application status by the
# employer/reviewer/publisher of the job
class JobApplicationStatus(models.Model):
	job_application_id = models.ForeignKey(JobApplications, related_name="job_application_id_status",
										on_delete=models.CASCADE)
	job_application_status_id = models.ForeignKey(ApplicationStatusLabels,
										related_name="job_application_status_id_status",
										on_delete=models.CASCADE)
	action_date = models.DateTimeField(null=True)
