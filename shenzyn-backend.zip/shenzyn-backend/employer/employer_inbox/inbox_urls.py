from django.urls import path, include
from .inbox_views import *

urlpatterns = [
	# GetPostedJobs API
	path('home/', InboxGenerator.as_view()),
	# GetOrganizationsOfProfilesAppliedForJob API
	path('<int:job_id>/organization-list/', AppliedProfilesOrganizationLister.as_view()),
	# GetProfilesAppliedForJob API
	path('<int:job_id>/', AppliedProfilesLister.as_view()),
	# GetSelectedProfileDetails API
	path('<int:job_id>/<int:candidate_id>/get-profile/', ProfileDetailsGenerator.as_view()),
	# ChangeProfileStatus API
	path('<int:job_id>/<int:candidate_id>/change-status/', ProfileStatusChanger.as_view()),
	# GetStatus API
	path('get-status/', GetStatusCodes.as_view()),
	# GetLocationsOfProfileAppliedForJob API
	path('<int:job_id>/location-list/', AppliedProfilesLocationLister.as_view())
]
