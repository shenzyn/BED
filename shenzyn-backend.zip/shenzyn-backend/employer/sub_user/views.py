from employer.employer_homepage.homepage_serializers import *
from rest_framework.views import APIView
from employer.decorators import *
from pinkjob.utils import *
from django.db.models import Q
import datetime
import pytz
tz = pytz.timezone('Asia/Kolkata')
import os
import traceback
os.environ['TZ'] = 'Asia/Kolkata'
# This function stores the sub-user data
class SubUserView(APIView):
    # make it count or select query
    def count_select_query(self, queryset_main, queryset_1, queryset_2, page, limit, status):
        count = queryset_main.count()
        data = []
        queryset_main = queryset_main[page: page+limit]
        for employer in queryset_main:
            # formatting
            dict = {
                "id": employer.employer_profile_id.id,
                "name": employer.employer_profile_id.user_account_id.first_name if employer.employer_profile_id and employer.employer_profile_id.user_account_id and employer.employer_profile_id.user_account_id.first_name else "",
                "email": employer.employer_profile_id.business_email,
                "designation": employer.employer_profile_id.designation_id.name if employer.employer_profile_id.designation_id and employer.employer_profile_id.designation_id.name else "",
                "permissions": employer.permissions,
                "added_by": employer.parent_id.first_name if employer.parent_id.first_name else ""
            }
            if status == "suspended":
                dict.update({"suspended_for": str((datetime.datetime.now().date() - employer.suspended_till).days)+" days"})
            elif status == "deleted":
                dict.update(
                    {"reason": employer.sub_user_reason, "updated_on": time.strftime('%d %b %Y %H:%M%p', time.localtime(employer.updated_on/1000))})
            data.append(dict)
        queryset_1 = queryset_1.count()
        queryset_2 = queryset_2.count()
        return data, count, queryset_1, queryset_2

    # query for status
    def status_query(self, status, user_id):
        return SubUserStatus.objects.filter(Q(parent_id__id=user_id) & Q(sub_user_status=status)).order_by('-id')

    # queries for active, suspended and deleted
    def querying(self, user_id):
        employer_profile_active = self.status_query("active", user_id)
        employer_profile_suspended = self.status_query("suspended", user_id)
        employer_profile_deleted = self.status_query("deleted", user_id)
        return employer_profile_active, employer_profile_suspended, employer_profile_deleted

    # profile to retrieve sub user
    @permission_required()
    def get(self, request):
        try:
            # for limit of a page
            limit = int(request.GET["limit"])
            # for page number
            page = int(request.GET["page"])
            page -= 1
            page *= limit
            status = request.GET["status"]
            header = {"name": "Name", "email": "Email", "designation": "Role", "permissions": "Permissions"}
            # for active subusers
            if status == "active":
                employer_profile_active, employer_profile_suspended, employer_profile_deleted = self.querying(
                    request.META["user_id"])
                header.update({"added_by": "Added By","actions":"Actions"})
                employer_profile_active, count, employer_profile_suspended, employer_profile_deleted = self.count_select_query(
                    employer_profile_active, employer_profile_suspended, employer_profile_deleted, page, limit, status)
                return Response({"status": True, "message": Message["SUB_USER"]["SUB_USER_FOUND"], "data": employer_profile_active,
                                 "active": count, "suspended": employer_profile_suspended, "header": header,
                                 "deleted": employer_profile_deleted}, status=200)
            elif status == "suspended":
                employer_profile_active, employer_profile_suspended, employer_profile_deleted = self.querying(
                    request.META["user_id"])
                header.update({"suspended_for": "Suspended for","actions":"Actions"})
                employer_profile_suspended, count, employer_profile_active, employer_profile_deleted = self.count_select_query(
                    employer_profile_suspended, employer_profile_active, employer_profile_deleted, page, limit, status)

                return Response({"status": True, "message": Message["SUB_USER"]["SUB_USER_FOUND"], "data": employer_profile_suspended,
                                 "active": employer_profile_active, "suspended": count, "header": header,
                                 "deleted": employer_profile_deleted}, status=200)
            elif status == "deleted":
                employer_profile_active, employer_profile_suspended, employer_profile_deleted = self.querying(
                    request.META["user_id"])
                header.update({"reason": "Reason", "updated_on": "Date & Time of deletion","actions":"Actions"})
                employer_profile_deleted, count, employer_profile_active, employer_profile_suspended = self.count_select_query(
                    employer_profile_deleted, employer_profile_active, employer_profile_suspended, page, limit, status)
                return Response({"status": True, "message": Message["SUB_USER"]["SUB_USER_FOUND"], "data": employer_profile_deleted,
                                 "active": employer_profile_active, "suspended": employer_profile_suspended,
                                 "deleted": count, "header": header}, status=200)
            return Response({"status": True, "message": Message["SUB_USER"]["CORRECT_STATUS"], "data": [], "header": header}, status=200)

            # data retrieval
        except Exception as e:
            return Response({"status": False, "message": format(e)}, status=200)

    # profile creation of sub user
    @permission_required()
    def post(self, request):
        try:
            data = request.data
            user_id = request.META["user_id"]
            # check account is already there if yes then update if no then create
            user_account = EmployerProfile.objects.filter(Q(business_email=data["email_id"]) & Q(is_business_email_verified=True))
            print(len(user_account), user_id)

            if user_account:
                sub_user = SubUserStatus.objects.filter(Q(employer_profile_id_id=user_account[0].id) & ~Q(sub_user_status='deleted'))
                if len(sub_user) > 0:
                    if sub_user[0].sub_user_status == "suspended":
                        return Response({"status": False, "message":Message["SUB_USER"]["SUB_USER_SUSPENDED_BUT_ADDING"]}, status=200)
                    if sub_user[0].sub_user_status == "active":

                        return Response({"status": False, "message":Message["SUB_USER"]["SUB_USER_ALREADY_THERE"]}, status=200)

                else:
                    del data["email_id"]
                    data["employer_profile_id_id"] = user_account[0].id;
                    data["sub_user_status"] = "active";
                    data["is_admin"] = False;
                    data["parent_id_id"] = user_id
                    data["updated_on"] = time.mktime(datetime.datetime.now().timetuple())*1000
                    SubUserStatus.objects.create(**data)
            # else:
            #     user_account = UserAccount.objects.create(
            #         first_name=data["first_name"], email_id=data["email_id"], is_employer=True, is_job_seeker=False,
            #         regestration_date=int(datetime.datetime.now().timestamp()*1000), is_email_verified=False,
            #         is_account_approved=False, is_email_notification_active=False, is_sms_notification_active=False)
            #     del data["email_id"]
            #     EmployerProfile.objects.create(user_account_id=user_account, parent_id_id=user_id, is_sub_user=False,
            #                                    employer_profile_status="active", is_admin=False,
            #                                    created_on=time.mktime(datetime.datetime.now().timetuple())*1000,
            #                                    updated_on=time.mktime(datetime.datetime.now().timetuple())*1000, **data)
            return Response({"status": True, "message": Message["SUB_USER"]["SUB_USER_UPDATED_SUCCESSFULLY"]}, status=200)
        except Exception as e:
            return Response({"status": False, "message":format(e)}, status=200)


class OneSubUserView(APIView):
    # profile retrieval of sub user
    @permission_required()
    def get(self, request, eid=None):
        try:
            # for reducing queries
            employer_profile = SubUserStatus.objects.filter(employer_profile_id__id=eid,sub_user_status="active").select_related('employer_profile_id__designation_id')
            employer_profile = employer_profile.select_related('employer_profile_id__organization_id')
            employer_profile = employer_profile.select_related('employer_profile_id__current_country')
            employer_profile = employer_profile.select_related('employer_profile_id__current_city')
            employer_profile = employer_profile.select_related('employer_profile_id__user_account_id')
            if not employer_profile:
                return Response({"status": False, "message": Message["SUB_USER"]["DATA_NOT_FOUND"]}, status=200)
            # formatting
            data = {
                "name":  employer_profile[0].employer_profile_id.user_account_id.first_name if  employer_profile[0].employer_profile_id and employer_profile[0].employer_profile_id.user_account_id.first_name else "" ,
                "email": employer_profile[0].employer_profile_id.user_account_id.email_id,
                "designation": employer_profile[0].employer_profile_id.designation_id.name if employer_profile[0] and employer_profile[0].employer_profile_id and employer_profile[0].employer_profile_id.designation_id and employer_profile[0].employer_profile_id.designation_id.name else "",
                "permissions": employer_profile[0].permissions}
            return Response({"status": True, "message": Message["SUB_USER"]["SUB_USER_FOUND"], "data": data}, status=200)
        except Exception as e:
            return Response({"status": False, "message": format(e)}, status=200)

    # updation of profile of sub user
    @permission_required()
    def patch(self, request, eid=None):
        try:
            data = request.data
            # print(data)
            parent_id = request.META["user_id"]
            if "email_id" in data:
                del data["email_id"]
            if "first_name" in data:
                del data["first_name"]
            employer_profile = SubUserStatus.objects.filter(employer_profile_id__id=eid,parent_id_id=parent_id).order_by('-id')[:1]
            if "employer_profile_status" not in data:
                data["employer_profile_status"] = "active"
            if data["employer_profile_status"] == "":
                print("deleting")
                data["employer_profile_status"] = "deleted"
                print(data["employer_profile_status"])
            if data["employer_profile_status"] == "suspended":
                data["suspended_till"] = datetime.datetime.now()
            # if data["employer_profile_status"] == "deleted":
            #     data[""]
            data["sub_user_status"] = data["employer_profile_status"];
            print(data["sub_user_status"])
            del data["employer_profile_status"];
            data["updated_on"] = time.mktime(datetime.datetime.now().timetuple())*1000;
            if employer_profile[0].sub_user_status != "deleted":
                #employer_profile.update(updated_on=time.mktime(datetime.datetime.now().timetuple())*1000,**data)
                print(employer_profile[0].id)
                SubUserStatus.objects.filter(id=employer_profile[0].id).update(**data)
                return Response({"status": True, "message": Message["SUB_USER"]["SUB_USER_UPDATED_SUCCESSFULLY"]}, status=200)
            else:
                return Response({"status": True, "message": Message["SUB_USER"]["SUB_USER_ALREADY_DELETED"]},
                                status=200)
        except Exception as e:
            #print(employer_profile[0].id)
            print(e)
            return Response({"status": False, "message": format(e)}, status=200)


class PermissionsSubUserView(APIView):
    # permissions of specific sub user
    @permission_required()
    def get(self, request, eid=None):
        try:
            employer_profile = SubUserStatus.objects.filter(employer_profile_id__user_account_id=request.META["user_id"],sub_user_status="active")
            print(employer_profile);
            if employer_profile:
                permissions_object = []
                if employer_profile[0].is_admin:
                    default_permissions = DefaultPermissions.objects.filter()
                    permissions_object = DefaultPermissionsSerializer(default_permissions, many=True).data
                else:
                    if employer_profile[0].permissions:
                        permissions = employer_profile[0].permissions.split(",")
                        for i in permissions:
                            permissions_object.append({"permission_name":i})
                        print(permissions_object)
                    else:
                        permissions_object = []
                return Response({"status": True, "message": Message["SUB_USER"]["SUB_USER_FOUND"], "data": permissions_object}, status=200)
            else:
                return Response({"status": False, "message": Message["SUB_USER"]["PERMISSION_NOT_FOUND"]}, status=200)
        except Exception as e:
            return Response({"status": False, "message": format(e)}, status=200)

class PermissionsViaEmailSubUserView(APIView):
    # permissions of specific sub user
    @permission_required()
    def get(self, request, eid=None):
        try:
            business_email_id = request.GET["business_email_id"]
            # employer_profile = SubUserStatus.objects.filter(employer_profile_id__business_email=business_email_id)
            # if employer_profile:
            parent_company_details = SubUserStatus.objects.filter(employer_profile_id__user_account_id=request.META["user_id"]);
            print(parent_company_details)
            employer_profile = EmployerProfile.objects.filter(Q(business_email=business_email_id) & Q(is_business_email_verified=True))
            if employer_profile:
                print("found such person")
                employer_profile1 = SubUserStatus.objects.filter(employer_profile_id_id=employer_profile[0].id).order_by('-id')
                if employer_profile1:
                    print("found another")
                    permissions = employer_profile1[0].permissions if employer_profile1[0].permissions else "" 
                    first_name = employer_profile1[0].employer_profile_id.user_account_id.first_name if employer_profile1[0].employer_profile_id  else ""
                    last_name = employer_profile1[0].employer_profile_id.user_account_id.last_name if employer_profile1[0].employer_profile_id.user_account_id else ""
                    designation = employer_profile1[0].employer_profile_id.designation_id.name if employer_profile1[0].employer_profile_id.designation_id else ""
                    name = ""
                    if employer_profile1[0].sub_user_status == "suspended":
                        return Response({"status": False, "message":Message["SUB_USER"]["SUB_USER_SUSPENDED_BUT_ADDING"]}, status=200)
                    if employer_profile1[0].sub_user_status == "active":
                        print(employer_profile1[0].company_details_id_id,parent_company_details[0].company_details_id_id)
                        if(employer_profile1[0].company_details_id_id==parent_company_details[0].company_details_id_id):
                            return Response({"status": False, "message":Message["SUB_USER"]["SUB_USER_ALREADY_THERE"]}, status=200)
                        else:
                            return Response({"status": False, "message":Message["SUB_USER"]["SUB_USER_ALREADY_THERE_IN_OTHER_SYSTEM"]}, status=200)
                    if first_name is not None:
                        name = first_name.strip() + " "
                    if last_name is not None:
                        name += last_name.strip() + " "
                    data = {"permissions": permissions, "name": name, "role": designation,"sub_user_status":employer_profile1[0].sub_user_status}
                    return Response({"status": True, "message": Message["SUB_USER"]["SUB_USER_FOUND"], "data": data}, status=200)
                else:
                    permissions = "" 
                    first_name = employer_profile[0].user_account_id.first_name if employer_profile[0].user_account_id  else ""
                    last_name = employer_profile[0].user_account_id.last_name if employer_profile[0].user_account_id else ""
                    designation = employer_profile[0].designation_id.name if employer_profile[0].designation_id else ""
                    name = ""
                    if first_name is not None:
                        name = first_name.strip() + " "
                    if last_name is not None:
                        name += last_name.strip() + " "
                    data = {"permissions": permissions, "name": name, "role": designation}
                    return Response({"status": True, "message": "", "data": data}, status=200)
            employer_profile = SubUserStatus.objects.filter(Q(employer_profile_id__business_email=business_email_id) & Q(employer_profile_id__is_business_email_verified=True))
            if employer_profile:
                permissions = employer_profile[0].permissions
                first_name = employer_profile[0].employer_profile_id.user_account_id.first_name
                last_name = employer_profile[0].employer_profile_id.user_account_id.last_name
                designation = employer_profile[0].employer_profile_id.designation_id.name
                name = ""
                if employer_profile[0].sub_user_status == "suspended":
                    return Response({"status": False, "message":Message["SUB_USER"]["SUB_USER_SUSPENDED_BUT_ADDING"]}, status=200)
                if employer_profile[0].sub_user_status == "active":
                    print()
                    if(employer_profile[0].company_details_id_id==parent_company_details[0].company_details_id_id):
                        return Response({"status": False, "message":Message["SUB_USER"]["SUB_USER_ALREADY_THERE"]}, status=200)
                    else:
                        return Response({"status": False, "message":Message["SUB_USER"]["SUB_USER_ALREADY_THERE_IN_OTHER_SYSTEM"]}, status=200)
                if first_name is not None:
                    name = first_name.strip() + " "
                if last_name is not None:
                    name += last_name.strip() + " "
                data = {"permissions": permissions, "name": name, "role": designation,"sub_user_status":employer_profile[0].sub_user_status}
                return Response({"status": True, "message": "sub employer found", "data": data}, status=200)
                data = {"permissions": permissions, "name": name, "role": designation}
                return Response({"status": True, "message": Message["SUB_USER"]["SUB_USER_FOUND"], "data": data}, status=200)
            else:
                return Response({"status": False, "message": Message["SUB_USER"]["BUSINESS_EMAIL_NOT_VERIFIED"]}, status=200)
            # else:
            #     return Response({"status": False, "message": Message["SUB_USER"]["BUSINESS_EMAIL_DONT_EXIST"]}, status=200)
        except Exception as e:
            return Response({"status": False, "message": format(e)}, status=200)


class DemoData(APIView):
    # permissions of specific sub user
    #@permission_required()
    def get(self, request, eid=None):
        try:
            for i in range(10):
                user_Account = UserAccount.objects.create(
                    first_name="Test"+str(i), last_name="Last Name"+str(i), email_id="test"+str(i)+"@gmail.com",
                    password="test@123", regestration_date = int(datetime.datetime.now().timestamp()*1000),
                    is_employer=True, is_email_verified=True)
                emp_entry = EmployerProfile.objects.create(
                    user_account_id=user_Account, designation_id__id=1, business_email="testing"+str(i),
                    is_business_email_verified=True)
                SubUserStatus.objects.create(
                    employer_profile_id="emp_entry",sub_user_status="active",
                    permissions="Admin,Add Sub User,Post Jobs,Search Resume - Video", is_admin=True)

            for i in range(11, 21):
                user_Account = UserAccount.objects.create(
                    first_name="Test"+str(i), last_name="Last Name"+str(i), email_id="test"+str(i)+"@gmail.com",
                    password="test@123", regestration_date = int(datetime.datetime.now().timestamp()*1000),
                    is_employer=True, is_email_verified=True)
                emp_entry = EmployerProfile.objects.create(
                    user_account_id=user_Account, designation_id__id=1, business_email="testing"+str(i),
                    is_business_email_verified=True)
                SubUserStatus.objects.create(
                    employer_profile_id="emp_entry",sub_user_status="suspended",
                    permissions="Admin,Add Sub User,Post Jobs,Search Resume - Video", is_admin=True)

            for i in range(22, 23):
                user_Account = UserAccount.objects.create(
                    first_name="Test"+str(i), last_name="Last Name"+str(i), email_id="test"+str(i)+"@gmail.com",
                    password="test@123", regestration_date = int(datetime.datetime.now().timestamp()*1000),
                    is_employer=True, is_email_verified=True)
                emp_entry = EmployerProfile.objects.create(
                    user_account_id=user_Account, designation_id__id=1, business_email="testing"+str(i),
                    is_business_email_verified=True)
                SubUserStatus.objects.create(
                    employer_profile_id="emp_entry",sub_user_status="deleted",
                    permissions="Admin,Add Sub User,Post Jobs,Search Resume - Video", is_admin=True)
            return Response({"status": True, "message": Message["SUB_USER"]["DATA_ADDED"]}, status=200)
        except Exception as e:
            return Response({"status": False, "message": format(e)}, status=200)


class HomepageStatus(APIView):
    @permission_required()
    def get(self, request):
        try:
            user_id, user_type = request.META["user_id"], request.META["user_type"]
            data = {}
            user_data = EmployerProfile.objects.filter(user_account_id=user_id)
            user_serialiser_data = EmployerHomepageStatusSerializer(user_data, many=True).data
            subuser_query = SubUserStatus.objects.filter(employer_profile_id__id=user_data[0].id).first()
            company_details_query = ""
            if subuser_query and subuser_query.company_details_id:
                company_details_query = CompanyDetails.objects.filter(id=subuser_query.company_details_id.id).first()
            if user_data:
                for value in user_serialiser_data:
                    about_employer = AboutEmployer.objects.filter(employer_id=value["id"])
                    if about_employer:
                        data["more_about_emp_status"] = True
                    else:
                        data["more_about_emp_status"] = False
                    data["business_email_verified_status"] = value["is_business_email_verified"]
                    data["account_email_verified_status"] = value["user_account_id"]["is_email_verified"]
                    data["mobile_number_verified_status"] = True if value["user_account_id"]["mobile_number"] else False
                if company_details_query != "" and company_details_query is not None:
                    data["pan_card_status"] = True if company_details_query.pan_file_path else False
                    data["pan_num"] = company_details_query.pan
                else:
                    data["pan_card_status"] = False
                    data["pan_num"] = ""
            else:
                data["business_email_verified_status"] = False
                data["account_email_verified_status"] = False
                data["mobile_number_verified_status"] = False
                data["more_about_emp_status"] = False
            return Response({"status": True, "message": Message["SUB_USER"]["SUCCESS"], "data":data}, status=200)
        except Exception as e:
            traceback.print_exc()
            return Response({"status": False, "message": format(e)}, status=200)